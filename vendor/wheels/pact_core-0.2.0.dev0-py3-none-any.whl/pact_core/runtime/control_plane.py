"""Single-committer Control Plane for sequential multi-Mission execution."""

from __future__ import annotations

import json
import threading
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import cast

from pact_core.adapters.base import AgentAdapter
from pact_core.artifacts import read_json, round_paths
from pact_core.config import LoopConfig
from pact_core.kernel import (
    ExecutionOutcome,
    ExecutionRequest,
    PromotionAuthorization,
    PromotionReceipt,
    execute,
    promote,
)
from pact_core.runtime.closure import evaluate_closure
from pact_core.runtime.manager import (
    DecisionProvider,
    ManagerDecisionRequest,
    decision_payload,
    validate_manager_decision_proposal,
)
from pact_core.runtime.planner import (
    PlanRevisionProposal,
    PlanningProvider,
    PlanningRequest,
    proposal_payload,
    validate_plan_revision_proposal,
)
from pact_core.runtime.planning import (
    InitialPlan,
    MissionDefinition,
    MissionStatus,
    classify_frontier,
    compute_frontier,
    scheduled_execution,
    validate_initial_plan,
)
from pact_core.runtime.projection import write_dashboard_projection
from pact_core.runtime.schemas import (
    CampaignStatus,
    RuntimeContractError,
    RuntimeStateError,
    goal_contract_criteria,
    validate_goal_contract,
)
from pact_core.runtime.store import CampaignReader, _CampaignStore
from pact_core.schemas import REVIEW_DECISION_SCHEMA


@dataclass(frozen=True, slots=True)
class CampaignRunRequest:
    workspace: Path
    contract_file: Path
    plan_file: Path
    worker: AgentAdapter
    reviewer: AgentAdapter
    verify_command: str | None
    max_rounds: int = 3
    verify_timeout_seconds: float = 1800.0
    allow_unverified: bool = False
    final_verify_command: str | None = None
    final_verify_timeout_seconds: float = 1800.0
    turn_timeout_seconds: float = 3600.0
    campaign_id: str | None = None
    worktree_root: Path | None = None
    planning_provider: PlanningProvider | None = None
    decision_provider: DecisionProvider | None = None


@dataclass(frozen=True, slots=True)
class CampaignRunResult:
    campaign_id: str
    campaign_dir: Path
    status: CampaignStatus
    revision: int
    next_action: str
    execution_outcomes: tuple[ExecutionOutcome, ...]
    promotion_receipts: tuple[PromotionReceipt, ...]
    evidence_refs: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class CampaignSummary:
    campaign_id: str
    status: CampaignStatus
    revision: int
    goal: str
    current_mission: str | None
    execution_status: str
    acceptance_gaps: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    next_action: str


class CampaignControlPlane:
    """The only production component that submits canonical Work State commits."""

    def run(self, request: CampaignRunRequest) -> CampaignRunResult:
        workspace = request.workspace.expanduser().resolve()
        if not workspace.is_dir():
            raise RuntimeContractError(f"workspace does not exist: {workspace}")
        contract = _read_contract_file(request.contract_file)
        ac_ids = tuple(item["id"] for item in goal_contract_criteria(contract))
        plan = _read_initial_plan_file(
            request.plan_file,
            workspace=workspace,
            acceptance_criterion_ids=ac_ids,
        )
        campaign_id = request.campaign_id or _build_campaign_id()
        store = _CampaignStore(workspace, campaign_id)
        state = store.initialize(contract, plan=plan)
        reader = CampaignReader(workspace, campaign_id)
        _refresh_projection(reader)
        outcomes: list[ExecutionOutcome] = []
        receipts: list[PromotionReceipt] = []
        evidence_refs: list[str] = []
        try:
            while _campaign_status(state) != "completed":
                next_action = _required_str(state, "next_action")
                if next_action != "execute_mission":
                    if next_action not in {
                        "manager_select_frontier",
                        "manager_resolve_empty_frontier",
                        "manager_decide",
                    } or request.decision_provider is None:
                        break
                    state, plan = _advance_governance(
                        state,
                        store=store,
                        contract=contract,
                        plan=plan,
                        decision_provider=request.decision_provider,
                        planning_provider=request.planning_provider,
                    )
                    _refresh_projection(reader)
                    continue
                input_revision = _revision(state)
                mission_id = _selected_mission_id(state)
                mission = plan.mission(mission_id)
                loop_id = _execution_loop_id(state)
                plan_revision = _plan_revision(state)
                stop_projection, projection_thread = _start_projection_monitor(reader)
                try:
                    outcome = execute(
                        ExecutionRequest(
                            config=LoopConfig(
                                workspace=workspace,
                                plan_file=store.mission_plan_path(
                                    mission_id,
                                    plan_revision=plan_revision,
                                ),
                                max_rounds=request.max_rounds,
                                verify_command=request.verify_command,
                                verify_timeout_seconds=request.verify_timeout_seconds,
                                allow_unverified=request.allow_unverified,
                                final_verify_command=request.final_verify_command,
                                final_verify_timeout_seconds=(
                                    request.final_verify_timeout_seconds
                                ),
                                turn_timeout_seconds=request.turn_timeout_seconds,
                                loop_id=loop_id,
                                worktree_root=request.worktree_root,
                            ),
                            worker=request.worker,
                            reviewer=request.reviewer,
                            promotion_mode="deferred",
                        )
                    )
                finally:
                    stop_projection.set()
                    projection_thread.join(timeout=1.0)
                    _refresh_projection(reader)
                outcomes.append(outcome)
                challenge = _plan_challenge_from_outcome(outcome)
                receipt = None
                if challenge is None:
                    receipt = _promote_if_ready(
                        store,
                        outcome,
                        expected_revision=input_revision,
                    )
                if receipt is not None:
                    receipts.append(receipt)
                accepted_ac_ids = (
                    mission.target_ac_ids
                    if receipt is not None and receipt.status in {"applied", "no_changes"}
                    else ()
                )
                progress = _progress_vector(
                    state,
                    mission=mission,
                    outcome=outcome,
                    challenge=challenge,
                    material_progress=bool(accepted_ac_ids),
                )
                evidence_ref = store.write_execution_evidence(
                    _execution_evidence(
                        store,
                        outcome,
                        mission=mission,
                        input_state_revision=input_revision,
                        accepted_ac_ids=accepted_ac_ids,
                        receipt=receipt,
                        challenge=challenge,
                        progress=progress,
                    )
                )
                evidence_refs.append(evidence_ref)
                next_state = _transition_after_execution(
                    state,
                    store=store,
                    plan=plan,
                    mission=mission,
                    outcome=outcome,
                    receipt=receipt,
                    evidence_ref=evidence_ref,
                    accepted_ac_ids=accepted_ac_ids,
                    current_ac_ids=ac_ids,
                    challenge=challenge,
                    progress=progress,
                )
                state = store.commit_work_state(
                    expected_revision=input_revision,
                    next_state=next_state,
                )
                _refresh_projection(reader)
        finally:
            _refresh_projection(reader)

        return _run_result(
            store,
            state,
            outcomes=outcomes,
            receipts=receipts,
            evidence_refs=evidence_refs,
        )

    def inspect(self, workspace: Path, campaign_id: str) -> CampaignSummary:
        """Reconstruct current meaning from canonical state and stable refs only."""
        store = _CampaignStore(workspace, campaign_id)
        state = store.read_current_state()
        contract = store.read_contract()
        store.read_plan_revision()
        execution = _required_object(state, "execution")
        acceptance = _required_object(state, "acceptance")
        frontier = _required_object(state, "frontier")
        selected = frontier.get("selected")
        if selected is not None and not isinstance(selected, str):
            raise RuntimeStateError("Work State selected Mission must be a string or null")
        gaps = _required_string_list(acceptance, "gaps")
        evidence_refs = _required_string_list(state, "evidence_refs")
        return CampaignSummary(
            campaign_id=campaign_id,
            status=_campaign_status(state),
            revision=_revision(state),
            goal=_required_str(contract, "goal"),
            current_mission=selected,
            execution_status=_required_str(execution, "status"),
            acceptance_gaps=tuple(gaps),
            evidence_refs=tuple(evidence_refs),
            next_action=_required_str(state, "next_action"),
        )


def _read_contract_file(path: Path) -> dict[str, object]:
    payload = _read_json_object(path, "Goal Contract")
    return validate_goal_contract(payload)


def _read_initial_plan_file(
    path: Path,
    *,
    workspace: Path,
    acceptance_criterion_ids: tuple[str, ...],
) -> InitialPlan:
    plan_file = path.expanduser()
    if not plan_file.is_absolute():
        plan_file = workspace / plan_file
    payload = _read_json_object(plan_file, "Initial Plan")
    return validate_initial_plan(
        payload,
        acceptance_criterion_ids=acceptance_criterion_ids,
    )


def _read_json_object(path: Path, label: str) -> dict[str, object]:
    try:
        payload = json.loads(path.expanduser().read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeContractError(f"{label} is not valid JSON: {path}") from exc
    if not isinstance(payload, dict):
        raise RuntimeContractError(f"{label} must be a JSON object")
    return payload


def _build_campaign_id() -> str:
    timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    return f"campaign-{timestamp}-{uuid.uuid4().hex[:8]}"


def _start_projection_monitor(
    reader: CampaignReader,
) -> tuple[threading.Event, threading.Thread]:
    stop = threading.Event()

    def monitor() -> None:
        while not stop.wait(0.2):
            _refresh_projection(reader)

    thread = threading.Thread(
        target=monitor,
        name=f"pact-dashboard-{reader.campaign_id}",
        daemon=True,
    )
    thread.start()
    return stop, thread


def _refresh_projection(reader: CampaignReader) -> None:
    """Keep projection failures from becoming a second work-state authority."""
    try:
        write_dashboard_projection(reader)
    except (OSError, RuntimeStateError):
        pass


def _promote_if_ready(
    store: _CampaignStore,
    outcome: ExecutionOutcome,
    *,
    expected_revision: int,
) -> PromotionReceipt | None:
    if not outcome.promotion_ready:
        return None
    store.assert_expected_revision(expected_revision)
    return promote(
        PromotionAuthorization(
            outcome=outcome,
            expected_source_workspace=outcome.source_workspace,
            expected_source_head_commit=outcome.source_head_commit,
            expected_source_index_tree=outcome.source_index_tree,
            expected_source_workspace_tree=outcome.source_workspace_tree,
            expected_candidate_checkpoint=outcome.candidate_checkpoint,
        )
    )


def _execution_evidence(
    store: _CampaignStore,
    outcome: ExecutionOutcome,
    *,
    mission: MissionDefinition,
    input_state_revision: int,
    accepted_ac_ids: tuple[str, ...],
    receipt: PromotionReceipt | None,
    challenge: dict[str, str] | None,
    progress: dict[str, object],
) -> dict[str, object]:
    refs = outcome.evidence
    review_decision = (
        round_paths(outcome.loop_dir, outcome.rounds).review_decision
        if outcome.rounds > 0
        else None
    )
    return {
        "execution_loop_id": outcome.loop_id,
        "subject": mission.id,
        "producer": "execution-kernel",
        "trust": "kernel_validated" if outcome.promotion_ready else "kernel_failed",
        "created_at": datetime.now(UTC).isoformat(),
        "contract_revision": 1,
        "plan_revision": progress["plan_revision"],
        "input_work_state_revision": input_state_revision,
        "target_ac_ids": list(mission.target_ac_ids),
        "claims": [
            {
                "ac_id": ac_id,
                "validity": "accepted",
                "trust": "kernel_validated",
            }
            for ac_id in accepted_ac_ids
        ],
        "kernel_outcome_schema": outcome.schema,
        "kernel_status": outcome.status,
        "stop_reason": outcome.stop_reason,
        "candidate_checkpoint": outcome.candidate_checkpoint,
        "round_gate_status": outcome.round_gate_status,
        "final_validation_status": outcome.final_validation_status,
        "promotion_ready": outcome.promotion_ready,
        "promotion_status": receipt.status if receipt is not None else "not_attempted",
        "plan_challenge": challenge,
        "progress": progress,
        "artifact_refs": {
            "manifest": store.relative_ref(refs.manifest),
            "initialization": store.relative_ref(refs.initialization),
            "state": store.relative_ref(refs.state),
            "events": store.relative_ref(refs.events),
            "worker_result": _optional_ref(store, refs.worker_result),
            "verification": _optional_ref(store, refs.verification),
            "reviewer_result": _optional_ref(store, refs.reviewer_result),
            "review_decision": _optional_ref(store, review_decision),
            "gate_decision": _optional_ref(store, refs.gate_decision),
            "final_validation": _optional_ref(store, refs.final_validation),
            "final_patch": store.relative_ref(refs.final_patch),
            "promotion": (
                store.relative_ref(receipt.artifact) if receipt is not None else None
            ),
        },
    }


def _optional_ref(store: _CampaignStore, path: Path | None) -> str | None:
    return store.relative_ref(path) if path is not None and path.is_file() else None


def _transition_after_execution(
    current: dict[str, object],
    *,
    store: _CampaignStore,
    plan: InitialPlan,
    mission: MissionDefinition,
    outcome: ExecutionOutcome,
    receipt: PromotionReceipt | None,
    evidence_ref: str,
    accepted_ac_ids: tuple[str, ...],
    current_ac_ids: tuple[str, ...],
    challenge: dict[str, str] | None,
    progress: dict[str, object],
) -> dict[str, object]:
    state = dict(current)
    mission_completed = receipt is not None and receipt.status in {
        "applied",
        "no_changes",
    }
    mission_records = _updated_mission_records(
        current,
        mission_id=mission.id,
        completed=mission_completed,
        evidence_ref=evidence_ref,
    )
    acceptance_records = _updated_acceptance_records(
        current,
        accepted_ac_ids=accepted_ac_ids,
        evidence_ref=evidence_ref,
    )
    evidence_ac_id_list: list[str] = []
    for record in acceptance_records:
        criterion_id = record.get("id")
        if record.get("status") == "satisfied" and isinstance(criterion_id, str):
            evidence_ac_id_list.append(criterion_id)
    evidence_ac_ids = tuple(evidence_ac_id_list)
    statuses = _mission_status_map(mission_records)
    closure = evaluate_closure(
        current_ac_ids=current_ac_ids,
        evidence_ac_ids=evidence_ac_ids,
        mission_statuses=tuple(statuses[definition.id] for definition in plan.missions),
    )
    promotion_ref = (
        store.relative_ref(receipt.artifact) if receipt is not None else None
    )
    execution: dict[str, object]
    current_execution = _required_object(current, "execution")
    attempt = current_execution.get("attempt")
    if isinstance(attempt, bool) or not isinstance(attempt, int) or attempt < 1:
        raise RuntimeStateError("scheduled execution attempt must be positive")
    if not mission_completed:
        status: CampaignStatus = "blocked"
        frontier: tuple[str, ...] = ()
        selected = mission.id
        selection_reason = "execution_blocked"
        next_action = "manager_decide"
        execution = {
            "mission_id": mission.id,
            "loop_id": outcome.loop_id,
            "status": outcome.status,
            "attempt": attempt,
            "outcome_ref": evidence_ref,
            "candidate_checkpoint": outcome.candidate_checkpoint,
            "promotion_ref": promotion_ref,
        }
    elif closure.completed:
        status = "completed"
        frontier = ()
        selected = None
        selection_reason = "campaign_complete"
        next_action = "none"
        execution = {
            "mission_id": mission.id,
            "loop_id": outcome.loop_id,
            "status": "promoted",
            "attempt": attempt,
            "outcome_ref": evidence_ref,
            "candidate_checkpoint": outcome.candidate_checkpoint,
            "promotion_ref": promotion_ref,
        }
    else:
        frontier = compute_frontier(plan, statuses)
        selected = frontier[0] if len(frontier) == 1 else None
        status, next_action, selection_reason = classify_frontier(frontier)
        mission_records = _activate_selected_mission(mission_records, selected)
        execution = scheduled_execution(
            store.campaign_id,
            selected,
            plan_revision=_plan_revision(current),
        )

    governance = dict(_required_object(current, "governance"))
    if mission_completed:
        governance.update(
            {
                "latest_challenge": None,
                "gap_signature": None,
                "consecutive_no_progress": 0,
                "trigger": None,
            }
        )
    else:
        no_progress_count = progress.get("consecutive_no_progress")
        if isinstance(no_progress_count, bool) or not isinstance(no_progress_count, int):
            raise RuntimeStateError("progress no-progress count must be an integer")
        governance.update(
            {
                "latest_challenge": challenge,
                "gap_signature": progress.get("gap_signature"),
                "consecutive_no_progress": no_progress_count,
                "trigger": (
                    "reviewer_plan_challenge"
                    if challenge is not None
                    else (
                        "repeated_no_progress"
                        if no_progress_count >= 2
                        else "no_progress_observation"
                    )
                ),
            }
        )

    state.update(
        {
            "status": status,
            "missions": mission_records,
            "frontier": {
                "eligible": list(frontier),
                "selected": selected,
                "selection_reason": selection_reason,
            },
            "acceptance": {
                "criteria": acceptance_records,
                "gaps": list(closure.gaps),
            },
            "execution": execution,
            "evidence_refs": [*_required_string_list(current, "evidence_refs"), evidence_ref],
            "governance": governance,
            "closure": {
                "completed": closure.completed,
                "reasons": list(closure.reasons),
            },
            "next_action": next_action,
        }
    )
    return state


def _plan_challenge_from_outcome(
    outcome: ExecutionOutcome,
) -> dict[str, str] | None:
    if outcome.rounds < 1 or outcome.stop_reason != "runtime_plan_challenge":
        return None
    path = round_paths(outcome.loop_dir, outcome.rounds).review_decision
    if not path.is_file():
        return None
    try:
        payload = read_json(path)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError):
        return None
    if (
        payload.get("schema") != REVIEW_DECISION_SCHEMA
        or payload.get("verdict_status") != "valid"
        or payload.get("verdict") != "continue"
        or payload.get("plan_challenge_status") != "valid"
    ):
        return None
    value = payload.get("plan_challenge")
    if not isinstance(value, dict):
        return None
    reason = value.get("reason")
    signature = value.get("gap_signature")
    action = value.get("recommended_action")
    if (
        not isinstance(reason, str)
        or not reason.strip()
        or not isinstance(signature, str)
        or not signature.strip()
        or action not in {"replan", "retry", "request_user", "block"}
    ):
        return None
    assert isinstance(action, str)
    return {
        "reason": reason.strip(),
        "gap_signature": signature.strip(),
        "recommended_action": action,
    }


def _progress_vector(
    state: dict[str, object],
    *,
    mission: MissionDefinition,
    outcome: ExecutionOutcome,
    challenge: dict[str, str] | None,
    material_progress: bool,
) -> dict[str, object]:
    plan_revision = _plan_revision(state)
    signature = (
        challenge["gap_signature"]
        if challenge is not None
        else "|".join(
            (
                f"mission:{mission.id}",
                f"plan:{plan_revision}",
                f"kernel:{outcome.status}",
                f"stop:{outcome.stop_reason}",
                f"gate:{outcome.round_gate_status or 'none'}",
                f"final:{outcome.final_validation_status or 'none'}",
            )
        )
    )
    governance = _required_object(state, "governance")
    previous_signature = governance.get("gap_signature")
    previous_count = governance.get("consecutive_no_progress", 0)
    if isinstance(previous_count, bool) or not isinstance(previous_count, int):
        raise RuntimeStateError("Work State no-progress count must be an integer")
    consecutive = (
        0
        if material_progress
        else previous_count + 1
        if previous_signature == signature
        else 1
    )
    patch = outcome.evidence.final_patch
    try:
        workspace_activity = bool(patch.read_text(encoding="utf-8").strip())
    except (OSError, UnicodeDecodeError):
        workspace_activity = False
    return {
        "mission_id": mission.id,
        "plan_revision": plan_revision,
        "gap_signature": signature,
        "workspace_activity": workspace_activity,
        "verification_improved": False,
        "new_valid_ac_evidence": material_progress,
        "acceptance_gap_changed": material_progress,
        "dependency_blocker_resolved": False,
        "material_progress": material_progress,
        "consecutive_no_progress": consecutive,
    }


def _updated_mission_records(
    state: dict[str, object],
    *,
    mission_id: str,
    completed: bool,
    evidence_ref: str,
) -> list[dict[str, object]]:
    records = state.get("missions")
    if not isinstance(records, list):
        raise RuntimeStateError("Work State missions must be an array")
    updated: list[dict[str, object]] = []
    found = False
    for record in records:
        if not isinstance(record, dict):
            raise RuntimeStateError("Work State Mission record must be an object")
        copy = dict(record)
        if record.get("id") == mission_id:
            found = True
            copy["status"] = "completed" if completed else "blocked"
            copy["execution_refs"] = [
                *_required_string_list(record, "execution_refs"),
                evidence_ref,
            ]
            copy["evidence_refs"] = [
                *_required_string_list(record, "evidence_refs"),
                evidence_ref,
            ]
        updated.append(copy)
    if not found:
        raise RuntimeStateError(f"selected Mission is absent from Work State: {mission_id}")
    return updated


def _updated_acceptance_records(
    state: dict[str, object],
    *,
    accepted_ac_ids: tuple[str, ...],
    evidence_ref: str,
) -> list[dict[str, object]]:
    acceptance = _required_object(state, "acceptance")
    records = acceptance.get("criteria")
    if not isinstance(records, list):
        raise RuntimeStateError("Work State acceptance criteria must be an array")
    updated: list[dict[str, object]] = []
    for record in records:
        if not isinstance(record, dict):
            raise RuntimeStateError("Work State acceptance record must be an object")
        copy = dict(record)
        criterion_id = record.get("id")
        if isinstance(criterion_id, str) and criterion_id in accepted_ac_ids:
            copy["status"] = "satisfied"
            refs = _required_string_list(record, "evidence_refs")
            copy["evidence_refs"] = [*refs, evidence_ref]
        updated.append(copy)
    return updated


def _mission_status_map(
    records: list[dict[str, object]],
) -> dict[str, MissionStatus]:
    result: dict[str, MissionStatus] = {}
    allowed = {"pending", "active", "blocked", "completed", "superseded", "abandoned"}
    for record in records:
        mission_id = record.get("id")
        status = record.get("status")
        if not isinstance(mission_id, str) or status not in allowed:
            raise RuntimeStateError("Work State Mission id/status is invalid")
        assert isinstance(status, str)
        result[mission_id] = cast(MissionStatus, status)
    return result


def _activate_selected_mission(
    records: list[dict[str, object]], mission_id: str | None
) -> list[dict[str, object]]:
    if mission_id is None:
        return records
    updated: list[dict[str, object]] = []
    found = False
    for record in records:
        copy = dict(record)
        if copy.get("id") == mission_id:
            if copy.get("status") != "pending":
                raise RuntimeStateError(
                    f"selected Mission is not pending: {mission_id}"
                )
            copy["status"] = "active"
            found = True
        updated.append(copy)
    if not found:
        raise RuntimeStateError(f"selected Mission is absent from Work State: {mission_id}")
    return updated


def _advance_governance(
    current: dict[str, object],
    *,
    store: _CampaignStore,
    contract: dict[str, object],
    plan: InitialPlan,
    decision_provider: DecisionProvider,
    planning_provider: PlanningProvider | None,
) -> tuple[dict[str, object], InitialPlan]:
    expected_revision = _revision(current)
    plan_revision = _plan_revision(current)
    frontier = tuple(
        _required_string_list(_required_object(current, "frontier"), "eligible")
    )
    governance = _required_object(current, "governance")
    next_action = _required_str(current, "next_action")
    trigger = {
        "manager_select_frontier": "multiple_frontier",
        "manager_resolve_empty_frontier": "empty_frontier",
    }.get(next_action)
    if trigger is None:
        trigger_value = governance.get("trigger")
        if not isinstance(trigger_value, str) or not trigger_value:
            raise RuntimeStateError("Manager decision requires a governance trigger")
        trigger = trigger_value
    no_progress_count = governance.get("consecutive_no_progress", 0)
    if isinstance(no_progress_count, bool) or not isinstance(no_progress_count, int):
        raise RuntimeStateError("Work State no-progress count must be an integer")
    manager_request = ManagerDecisionRequest(
        campaign_id=store.campaign_id,
        phase="route",
        contract_revision=1,
        plan_revision=plan_revision,
        work_state_revision=expected_revision,
        trigger=trigger,
        frontier=frontier,
        retry_allowed=(
            trigger in {"no_progress_observation", "reviewer_plan_challenge"}
            and no_progress_count < 2
        ),
        projection=_manager_projection(
            current,
            contract=contract,
            plan=plan,
            trigger=trigger,
        ),
        artifact_dir=(
            store.paths.semantic_artifacts
            / f"state-{expected_revision:06d}-manager-route"
        ),
    )
    try:
        route = validate_manager_decision_proposal(
            decision_provider.decide(manager_request),
            request=manager_request,
        )
    except RuntimeContractError as exc:
        return (
            _commit_governance_block(
                current,
                store=store,
                expected_revision=expected_revision,
                next_action="manager_protocol_error",
                reason=str(exc),
            ),
            plan,
        )
    route_ref = store.write_manager_decision(
        decision_payload(route),
        work_state_revision=expected_revision,
        phase="route",
        rationale=route.reason,
    )
    if route.action == "select":
        assert route.selected_mission_id is not None
        return (
            _commit_selected_mission(
                current,
                store=store,
                expected_revision=expected_revision,
                mission_id=route.selected_mission_id,
                decision_ref=route_ref,
            ),
            plan,
        )
    if route.action == "retry":
        return (
            _commit_retry(
                current,
                store=store,
                expected_revision=expected_revision,
                decision_ref=route_ref,
            ),
            plan,
        )
    if route.action in {"request_user", "block"}:
        return (
            _commit_governance_block(
                current,
                store=store,
                expected_revision=expected_revision,
                next_action=(
                    "await_user_decision"
                    if route.action == "request_user"
                    else "manager_blocked"
                ),
                reason=route.reason,
                manager_ref=route_ref,
            ),
            plan,
        )
    if route.action != "request_replan":
        raise RuntimeStateError(f"unsupported Manager routing action: {route.action}")
    if planning_provider is None:
        return (
            _commit_governance_block(
                current,
                store=store,
                expected_revision=expected_revision,
                next_action="planner_unavailable",
                reason="Manager requested replan but no PlanningProvider was configured",
                manager_ref=route_ref,
            ),
            plan,
        )

    ac_ids = tuple(item["id"] for item in goal_contract_criteria(contract))
    planning_request = PlanningRequest(
        campaign_id=store.campaign_id,
        contract_revision=1,
        plan_revision=plan_revision,
        work_state_revision=expected_revision,
        trigger=trigger,
        manager_constraints=route.constraints,
        acceptance_criterion_ids=ac_ids,
        parent_plan=plan,
        projection=_planner_projection(
            current,
            contract=contract,
            plan=plan,
            trigger=trigger,
            manager_constraints=route.constraints,
        ),
        artifact_dir=(
            store.paths.semantic_artifacts
            / f"state-{expected_revision:06d}-planner"
        ),
    )
    try:
        proposal = validate_plan_revision_proposal(
            planning_provider.propose(planning_request),
            request=planning_request,
        )
    except RuntimeContractError as exc:
        return (
            _commit_governance_block(
                current,
                store=store,
                expected_revision=expected_revision,
                next_action="planner_protocol_error",
                reason=str(exc),
                manager_ref=route_ref,
            ),
            plan,
        )
    proposal_ref = store.write_planner_proposal(
        proposal_payload(proposal),
        proposed_revision=plan_revision + 1,
        rationale=proposal.rationale,
    )
    if not _proposal_resolves_triggered_route(current, proposal):
        return (
            _commit_governance_block(
                current,
                store=store,
                expected_revision=expected_revision,
                next_action="planner_route_not_replaced",
                reason="Planner proposal did not supersede the challenged/blocked Mission",
                manager_ref=route_ref,
                planner_ref=proposal_ref,
            ),
            plan,
        )
    review_request = ManagerDecisionRequest(
        campaign_id=store.campaign_id,
        phase="review_plan",
        contract_revision=1,
        plan_revision=plan_revision,
        work_state_revision=expected_revision,
        trigger="planner_proposal",
        frontier=frontier,
        retry_allowed=False,
        projection=_manager_review_projection(
            current,
            contract=contract,
            proposal=proposal,
            proposal_ref=proposal_ref,
        ),
        proposal_sha256=proposal.sha256,
        artifact_dir=(
            store.paths.semantic_artifacts
            / f"state-{expected_revision:06d}-manager-review"
        ),
    )
    try:
        approval = validate_manager_decision_proposal(
            decision_provider.decide(review_request),
            request=review_request,
        )
    except RuntimeContractError as exc:
        return (
            _commit_governance_block(
                current,
                store=store,
                expected_revision=expected_revision,
                next_action="manager_review_protocol_error",
                reason=str(exc),
                manager_ref=route_ref,
                planner_ref=proposal_ref,
            ),
            plan,
        )
    approval_ref = store.write_manager_decision(
        decision_payload(approval),
        work_state_revision=expected_revision,
        phase="review_plan",
        rationale=approval.reason,
    )
    if approval.action != "approve_plan":
        action_map = {
            "request_user": "await_user_decision",
            "request_revision": "planner_revision_requested",
            "reject_plan": "planner_proposal_rejected",
            "block": "manager_blocked",
        }
        return (
            _commit_governance_block(
                current,
                store=store,
                expected_revision=expected_revision,
                next_action=action_map[approval.action],
                reason=approval.reason,
                manager_ref=approval_ref,
                planner_ref=proposal_ref,
                additional_manager_ref=route_ref,
            ),
            plan,
        )
    if _affected_route_has_accepted_evidence(current, proposal):
        return (
            _commit_governance_block(
                current,
                store=store,
                expected_revision=expected_revision,
                next_action="post_evidence_replan_unsupported",
                reason="R3 cannot supersede a Mission with accepted Evidence or promotion",
                manager_ref=approval_ref,
                planner_ref=proposal_ref,
                additional_manager_ref=route_ref,
            ),
            plan,
        )
    plan_ref = store.write_plan_revision(
        expected_work_state_revision=expected_revision,
        expected_plan_revision=plan_revision,
        plan=proposal.plan,
        reason=proposal.reason,
        operations=proposal.operations,
        planner_proposal_ref=proposal_ref,
        manager_approval_ref=approval_ref,
    )
    return (
        _commit_approved_plan(
            current,
            store=store,
            expected_revision=expected_revision,
            proposal=proposal,
            plan_ref=plan_ref,
            route_ref=route_ref,
            proposal_ref=proposal_ref,
            approval_ref=approval_ref,
        ),
        proposal.plan,
    )


def _commit_selected_mission(
    current: dict[str, object],
    *,
    store: _CampaignStore,
    expected_revision: int,
    mission_id: str,
    decision_ref: str,
) -> dict[str, object]:
    records = _activate_selected_mission(_copy_mission_records(current), mission_id)
    state = dict(current)
    governance = _governance_with_refs(current, manager_refs=(decision_ref,))
    governance["trigger"] = None
    state.update(
        {
            "status": "active",
            "missions": records,
            "frontier": {
                "eligible": _required_string_list(
                    _required_object(current, "frontier"), "eligible"
                ),
                "selected": mission_id,
                "selection_reason": "manager_selected_frontier",
            },
            "execution": scheduled_execution(
                store.campaign_id,
                mission_id,
                plan_revision=_plan_revision(current),
            ),
            "governance": governance,
            "next_action": "execute_mission",
        }
    )
    return store.commit_work_state(
        expected_revision=expected_revision,
        next_state=state,
    )


def _commit_retry(
    current: dict[str, object],
    *,
    store: _CampaignStore,
    expected_revision: int,
    decision_ref: str,
) -> dict[str, object]:
    frontier = _required_object(current, "frontier")
    mission_id = frontier.get("selected")
    if not isinstance(mission_id, str):
        raise RuntimeStateError("Manager retry requires a selected Mission")
    records = _copy_mission_records(current)
    found = False
    for record in records:
        if record.get("id") == mission_id:
            if record.get("status") != "blocked":
                raise RuntimeStateError("Manager retry requires a blocked Mission")
            record["status"] = "active"
            found = True
    if not found:
        raise RuntimeStateError("Manager retry Mission is absent from Work State")
    execution = _required_object(current, "execution")
    attempt = execution.get("attempt")
    if isinstance(attempt, bool) or not isinstance(attempt, int) or attempt < 1:
        raise RuntimeStateError("Manager retry requires a prior execution attempt")
    governance = _governance_with_refs(current, manager_refs=(decision_ref,))
    governance["trigger"] = None
    state = dict(current)
    state.update(
        {
            "status": "active",
            "missions": records,
            "frontier": {
                "eligible": [mission_id],
                "selected": mission_id,
                "selection_reason": "manager_reasoned_retry",
            },
            "execution": scheduled_execution(
                store.campaign_id,
                mission_id,
                plan_revision=_plan_revision(current),
                attempt=attempt + 1,
            ),
            "governance": governance,
            "next_action": "execute_mission",
        }
    )
    return store.commit_work_state(
        expected_revision=expected_revision,
        next_state=state,
    )


def _commit_governance_block(
    current: dict[str, object],
    *,
    store: _CampaignStore,
    expected_revision: int,
    next_action: str,
    reason: str,
    manager_ref: str | None = None,
    planner_ref: str | None = None,
    additional_manager_ref: str | None = None,
) -> dict[str, object]:
    refs = tuple(
        ref for ref in (additional_manager_ref, manager_ref) if ref is not None
    )
    governance = _governance_with_refs(
        current,
        manager_refs=refs,
        planner_ref=planner_ref,
    )
    governance["block_reason"] = reason
    state = dict(current)
    state.update(
        {
            "status": "blocked",
            "governance": governance,
            "next_action": next_action,
        }
    )
    return store.commit_work_state(
        expected_revision=expected_revision,
        next_state=state,
    )


def _commit_approved_plan(
    current: dict[str, object],
    *,
    store: _CampaignStore,
    expected_revision: int,
    proposal: PlanRevisionProposal,
    plan_ref: str,
    route_ref: str,
    proposal_ref: str,
    approval_ref: str,
) -> dict[str, object]:
    current_records = {
        record["id"]: record for record in _copy_mission_records(current)
    }
    superseded_ids = {
        old_id for mission in proposal.plan.missions for old_id in mission.supersedes
    }
    records: list[dict[str, object]] = []
    for mission in proposal.plan.missions:
        previous = current_records.get(mission.id)
        if previous is None:
            record: dict[str, object] = {
                "id": mission.id,
                "status": "pending",
                "execution_refs": [],
                "evidence_refs": [],
            }
        else:
            record = dict(previous)
        if mission.id in superseded_ids:
            record["status"] = "superseded"
        records.append(record)
    statuses = _mission_status_map(records)
    frontier = compute_frontier(proposal.plan, statuses)
    selected = frontier[0] if len(frontier) == 1 else None
    status, next_action, selection_reason = classify_frontier(frontier)
    records = _activate_selected_mission(records, selected)
    governance = _governance_with_refs(
        current,
        manager_refs=(route_ref, approval_ref),
        planner_ref=proposal_ref,
    )
    governance.update(
        {
            "latest_challenge": None,
            "gap_signature": None,
            "consecutive_no_progress": 0,
            "trigger": None,
            "block_reason": None,
        }
    )
    state = dict(current)
    state.update(
        {
            "status": status,
            "plan_revision": proposal.parent_plan_revision + 1,
            "plan_ref": plan_ref,
            "missions": records,
            "frontier": {
                "eligible": list(frontier),
                "selected": selected,
                "selection_reason": selection_reason,
            },
            "execution": scheduled_execution(
                store.campaign_id,
                selected,
                plan_revision=proposal.parent_plan_revision + 1,
            ),
            "governance": governance,
            "closure": {
                "completed": False,
                "reasons": ["missions_not_completed", "acceptance_evidence_missing"],
            },
            "next_action": next_action,
        }
    )
    return store.commit_work_state(
        expected_revision=expected_revision,
        next_state=state,
    )


def _affected_route_has_accepted_evidence(
    current: dict[str, object], proposal: PlanRevisionProposal
) -> bool:
    affected = set(proposal.affected_mission_ids)
    for record in _copy_mission_records(current):
        mission_id = record.get("id")
        if mission_id not in affected:
            continue
        if record.get("status") == "completed":
            return True
    acceptance = _required_object(current, "acceptance")
    criteria = acceptance.get("criteria")
    if not isinstance(criteria, list):
        raise RuntimeStateError("Work State acceptance criteria must be an array")
    affected_ac_ids = set(proposal.affected_ac_ids)
    for criterion in criteria:
        if not isinstance(criterion, dict):
            raise RuntimeStateError("Work State acceptance record must be an object")
        if (
            criterion.get("id") in affected_ac_ids
            and criterion.get("status") == "satisfied"
        ):
            return True
    return False


def _proposal_resolves_triggered_route(
    current: dict[str, object], proposal: PlanRevisionProposal
) -> bool:
    frontier = _required_object(current, "frontier")
    selected = frontier.get("selected")
    if not isinstance(selected, str):
        return True
    current_status = next(
        (
            record.get("status")
            for record in _copy_mission_records(current)
            if record.get("id") == selected
        ),
        None,
    )
    if current_status != "blocked":
        return True
    superseded_ids = {
        old_id for mission in proposal.plan.missions for old_id in mission.supersedes
    }
    return selected in superseded_ids


def _governance_with_refs(
    current: dict[str, object],
    *,
    manager_refs: tuple[str, ...] = (),
    planner_ref: str | None = None,
) -> dict[str, object]:
    governance = dict(_required_object(current, "governance"))
    existing = _required_string_list(governance, "manager_decision_refs")
    governance["manager_decision_refs"] = [*existing, *manager_refs]
    if planner_ref is not None:
        governance["planner_proposal_ref"] = planner_ref
    return governance


def _copy_mission_records(current: dict[str, object]) -> list[dict[str, object]]:
    value = current.get("missions")
    if not isinstance(value, list):
        raise RuntimeStateError("Work State missions must be an array")
    result: list[dict[str, object]] = []
    for item in value:
        if not isinstance(item, dict):
            raise RuntimeStateError("Work State Mission record must be an object")
        result.append(dict(item))
    return result


def _plan_projection(plan: InitialPlan) -> dict[str, object]:
    return {
        "constraints": list(plan.constraints),
        "missions": [
            {
                "id": mission.id,
                "objective": mission.objective,
                "target_ac_ids": list(mission.target_ac_ids),
                "dependencies": list(mission.dependencies),
                "successors": list(mission.successors),
                "supersedes": list(mission.supersedes),
                "verification_intent": mission.verification_intent,
            }
            for mission in plan.missions
        ],
    }


def _bounded_state_projection(state: dict[str, object]) -> dict[str, object]:
    return {
        "revision": _revision(state),
        "status": _campaign_status(state),
        "plan_revision": _plan_revision(state),
        "missions": _copy_mission_records(state),
        "frontier": dict(_required_object(state, "frontier")),
        "acceptance": dict(_required_object(state, "acceptance")),
        "governance": dict(_required_object(state, "governance")),
        "next_action": _required_str(state, "next_action"),
    }


def _manager_projection(
    state: dict[str, object],
    *,
    contract: dict[str, object],
    plan: InitialPlan,
    trigger: str,
) -> dict[str, object]:
    return {
        "campaign_id": state.get("campaign_id"),
        "contract_revision": 1,
        "plan_revision": _plan_revision(state),
        "work_state_revision": _revision(state),
        "trigger": trigger,
        "goal_contract": contract,
        "plan": _plan_projection(plan),
        "work_state": _bounded_state_projection(state),
    }


def _planner_projection(
    state: dict[str, object],
    *,
    contract: dict[str, object],
    plan: InitialPlan,
    trigger: str,
    manager_constraints: tuple[str, ...],
) -> dict[str, object]:
    projection = _manager_projection(
        state,
        contract=contract,
        plan=plan,
        trigger=trigger,
    )
    projection["manager_constraints"] = list(manager_constraints)
    return projection


def _manager_review_projection(
    state: dict[str, object],
    *,
    contract: dict[str, object],
    proposal: PlanRevisionProposal,
    proposal_ref: str,
) -> dict[str, object]:
    return {
        "campaign_id": state.get("campaign_id"),
        "contract_revision": 1,
        "plan_revision": _plan_revision(state),
        "work_state_revision": _revision(state),
        "goal_contract": contract,
        "proposal_ref": proposal_ref,
        "proposal_sha256": proposal.sha256,
        "proposal": proposal_payload(proposal),
    }


def _selected_mission_id(state: dict[str, object]) -> str:
    frontier = _required_object(state, "frontier")
    selected = frontier.get("selected")
    eligible = _required_string_list(frontier, "eligible")
    if not isinstance(selected, str) or selected not in eligible:
        raise RuntimeStateError("active Work State requires an eligible selected Mission")
    return selected


def _execution_loop_id(state: dict[str, object]) -> str:
    return _required_str(_required_object(state, "execution"), "loop_id")


def _run_result(
    store: _CampaignStore,
    state: dict[str, object],
    *,
    outcomes: list[ExecutionOutcome],
    receipts: list[PromotionReceipt],
    evidence_refs: list[str],
) -> CampaignRunResult:
    return CampaignRunResult(
        campaign_id=store.campaign_id,
        campaign_dir=store.paths.campaign_dir,
        status=_campaign_status(state),
        revision=_revision(state),
        next_action=_required_str(state, "next_action"),
        execution_outcomes=tuple(outcomes),
        promotion_receipts=tuple(receipts),
        evidence_refs=tuple(evidence_refs),
    )


def _required_object(payload: dict[str, object], key: str) -> dict[str, object]:
    value = payload.get(key)
    if not isinstance(value, dict):
        raise RuntimeStateError(f"field {key!r} must be an object")
    return value


def _required_str(payload: dict[str, object], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str):
        raise RuntimeStateError(f"field {key!r} must be a string")
    return value


def _required_string_list(payload: dict[str, object], key: str) -> list[str]:
    value = payload.get(key)
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise RuntimeStateError(f"field {key!r} must be an array of strings")
    return value


def _revision(state: dict[str, object]) -> int:
    value = state.get("revision")
    if isinstance(value, bool) or not isinstance(value, int):
        raise RuntimeStateError("Work State revision must be an integer")
    return value


def _plan_revision(state: dict[str, object]) -> int:
    value = state.get("plan_revision")
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise RuntimeStateError("Work State Plan revision must be a positive integer")
    return value


def _campaign_status(state: dict[str, object]) -> CampaignStatus:
    value = state.get("status")
    if value not in {"active", "blocked", "completed"}:
        raise RuntimeStateError(f"unsupported Campaign status: {value!r}")
    assert isinstance(value, str)
    return value
