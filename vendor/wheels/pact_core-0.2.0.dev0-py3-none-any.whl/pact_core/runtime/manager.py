"""Manager decision contract and thin AgentAdapter-backed provider."""

from __future__ import annotations

import json
import tempfile
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Literal, Protocol, cast, runtime_checkable

from pact_core.adapters.base import AgentAdapter
from pact_core.prompts import (
    build_manager_prompt,
    build_semantic_json_repair_prompt,
)
from pact_core.runtime.schemas import (
    MANAGER_DECISION_PROPOSAL_SCHEMA,
    RuntimeContractError,
    RuntimeRepairableOutputError,
)
from pact_core.schemas import TurnRequest

ManagerPhase = Literal["route", "review_plan"]
ManagerAction = Literal[
    "select",
    "retry",
    "request_replan",
    "request_user",
    "block",
    "approve_plan",
    "reject_plan",
    "request_revision",
]


@dataclass(frozen=True, slots=True)
class ManagerDecisionRequest:
    campaign_id: str
    phase: ManagerPhase
    contract_revision: int
    plan_revision: int
    work_state_revision: int
    trigger: str
    frontier: tuple[str, ...]
    retry_allowed: bool
    projection: dict[str, object]
    proposal_sha256: str | None = None
    artifact_dir: Path | None = None


@dataclass(frozen=True, slots=True)
class ManagerDecisionProposal:
    phase: ManagerPhase
    action: ManagerAction
    expected_plan_revision: int
    expected_work_state_revision: int
    reason: str
    selected_mission_id: str | None = None
    constraints: tuple[str, ...] = ()
    proposal_sha256: str | None = None
    repair_attempted: bool = False


@runtime_checkable
class DecisionProvider(Protocol):
    def decide(self, request: ManagerDecisionRequest) -> ManagerDecisionProposal:
        """Return one semantic decision proposal without canonical write access."""
        ...


class FakeDecisionProvider:
    """Deterministic Manager decision script for hermetic Runtime tests."""

    def __init__(self, decisions: list[ManagerDecisionProposal]) -> None:
        self._decisions = list(decisions)
        self._next = 0
        self.requests: list[ManagerDecisionRequest] = []

    def decide(self, request: ManagerDecisionRequest) -> ManagerDecisionProposal:
        self.requests.append(request)
        if self._next >= len(self._decisions):
            raise AssertionError("FakeDecisionProvider script exhausted")
        decision = self._decisions[self._next]
        self._next += 1
        return decision


class AdapterDecisionProvider:
    """Run Manager turns through an existing AgentAdapter process boundary."""

    def __init__(self, adapter: AgentAdapter, *, timeout_seconds: float = 3600.0) -> None:
        self._adapter = adapter
        self._timeout_seconds = timeout_seconds
        self._probed = False

    def decide(self, request: ManagerDecisionRequest) -> ManagerDecisionProposal:
        first = self._run(
            build_manager_prompt(
                phase=request.phase,
                projection=request.projection,
                proposal_schema=MANAGER_DECISION_PROPOSAL_SCHEMA,
            ),
            request.artifact_dir,
            "initial",
        )
        try:
            return parse_manager_decision(first, request=request)
        except RuntimeRepairableOutputError as initial_error:
            semantic_fingerprint = _manager_repair_fingerprint(first)
            if semantic_fingerprint is None:
                raise initial_error
            repair = self._run(
                build_semantic_json_repair_prompt(
                    role="Manager",
                    invalid_output=first,
                    error=str(initial_error),
                    contract=manager_output_contract(request.phase),
                ),
                request.artifact_dir,
                "repair",
            )
            try:
                decision = parse_manager_decision(repair, request=request)
            except RuntimeContractError as repair_error:
                raise RuntimeContractError(
                    f"Manager decision remained invalid after one format repair: "
                    f"{repair_error}"
                ) from repair_error
            repaired_fingerprint = _manager_repair_fingerprint(
                json.dumps(decision_payload(decision))
            )
            if repaired_fingerprint != semantic_fingerprint:
                raise RuntimeContractError(
                    "format repair changed Manager semantics"
                )
            return replace(decision, repair_attempted=True)

    def _run(self, prompt: str, artifact_dir: Path | None, attempt: str) -> str:
        if not self._probed:
            probe = self._adapter.probe()
            if not probe.available:
                raise RuntimeContractError(
                    f"Manager adapter is unavailable: {probe.detail or probe.version}"
                )
            self._probed = True
        with tempfile.TemporaryDirectory(prefix="pact-manager-") as raw_workdir:
            turn_artifacts = artifact_dir / attempt if artifact_dir is not None else None
            result = self._adapter.run_turn(
                TurnRequest(
                    role="worker",
                    prompt=prompt,
                    workdir=Path(raw_workdir),
                    timeout_seconds=self._timeout_seconds,
                    artifact_dir=turn_artifacts,
                )
            )
        if result.status != "completed" or not result.final_text.strip():
            raise RuntimeContractError(
                f"Manager provider turn was unusable: {result.status}"
            )
        return result.final_text


def manager_output_contract(phase: ManagerPhase) -> str:
    if phase == "route":
        actions = "select, retry, request_replan, request_user, or block"
    else:
        actions = "approve_plan, reject_plan, request_revision, request_user, or block"
    return (
        "exactly one JSON object with schema, phase, action, "
        "expected_plan_revision, expected_work_state_revision, reason, "
        f"and action-specific fields; action must be {actions}"
    )


def parse_manager_decision(
    raw_text: str,
    *,
    request: ManagerDecisionRequest,
) -> ManagerDecisionProposal:
    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise RuntimeRepairableOutputError(
            f"Manager decision is not valid JSON: {exc.msg}"
        ) from exc
    if not isinstance(payload, dict):
        raise RuntimeRepairableOutputError("Manager decision must be a JSON object")
    base_fields = {
        "schema",
        "phase",
        "action",
        "expected_plan_revision",
        "expected_work_state_revision",
        "reason",
    }
    optional_fields = {"selected_mission_id", "constraints", "proposal_sha256"}
    if not base_fields.issubset(payload) or set(payload).difference(
        base_fields | optional_fields
    ):
        raise RuntimeRepairableOutputError("Manager decision fields are invalid")
    if payload.get("schema") != MANAGER_DECISION_PROPOSAL_SCHEMA:
        raise RuntimeRepairableOutputError("unsupported Manager decision schema")
    captured_phase = payload.get("phase")
    if captured_phase != request.phase:
        raise RuntimeContractError("Manager decision phase does not match request")
    phase = request.phase
    plan_revision = _required_revision(payload, "expected_plan_revision")
    state_revision = _required_revision(payload, "expected_work_state_revision")
    if plan_revision != request.plan_revision:
        raise RuntimeContractError("Manager decision Plan revision is stale")
    if state_revision != request.work_state_revision:
        raise RuntimeContractError("Manager decision Work State revision is stale")
    action = payload.get("action")
    route_actions = {"select", "retry", "request_replan", "request_user", "block"}
    review_actions = {
        "approve_plan",
        "reject_plan",
        "request_revision",
        "request_user",
        "block",
    }
    allowed = route_actions if phase == "route" else review_actions
    if not isinstance(action, str) or action not in allowed:
        raise RuntimeContractError(f"Manager action is invalid for phase {phase}")
    reason = _required_text(payload, "reason")
    selected = payload.get("selected_mission_id")
    constraints_raw = payload.get("constraints", [])
    constraints = _string_tuple(constraints_raw, "constraints")
    proposal_sha = payload.get("proposal_sha256")
    if selected is not None and not isinstance(selected, str):
        raise RuntimeContractError("selected_mission_id must be a string or null")
    if proposal_sha is not None and not isinstance(proposal_sha, str):
        raise RuntimeContractError("proposal_sha256 must be a string or null")
    if action == "select":
        if selected is None or selected not in request.frontier:
            raise RuntimeContractError("Manager selected a Mission outside the Frontier")
    elif selected is not None:
        raise RuntimeContractError("only select may include selected_mission_id")
    if action == "retry" and not request.retry_allowed:
        raise RuntimeContractError("Manager retry is not allowed for this trigger")
    if action != "request_replan" and constraints:
        raise RuntimeContractError("only request_replan may include constraints")
    if phase == "review_plan":
        if not request.proposal_sha256 or proposal_sha != request.proposal_sha256:
            raise RuntimeContractError("Manager review is not bound to the Planner proposal")
    elif proposal_sha is not None:
        raise RuntimeContractError("routing decision cannot include proposal_sha256")
    return ManagerDecisionProposal(
        phase=phase,
        action=cast(ManagerAction, action),
        expected_plan_revision=plan_revision,
        expected_work_state_revision=state_revision,
        reason=reason,
        selected_mission_id=selected,
        constraints=constraints,
        proposal_sha256=proposal_sha,
    )


def decision_payload(decision: ManagerDecisionProposal) -> dict[str, object]:
    payload: dict[str, object] = {
        "schema": MANAGER_DECISION_PROPOSAL_SCHEMA,
        "phase": decision.phase,
        "action": decision.action,
        "expected_plan_revision": decision.expected_plan_revision,
        "expected_work_state_revision": decision.expected_work_state_revision,
        "reason": decision.reason,
    }
    if decision.selected_mission_id is not None:
        payload["selected_mission_id"] = decision.selected_mission_id
    if decision.constraints:
        payload["constraints"] = list(decision.constraints)
    if decision.proposal_sha256 is not None:
        payload["proposal_sha256"] = decision.proposal_sha256
    return payload


def validate_manager_decision_proposal(
    decision: ManagerDecisionProposal,
    *,
    request: ManagerDecisionRequest,
) -> ManagerDecisionProposal:
    """Apply the same strict checks to programmatic/Fake provider output."""
    normalized = parse_manager_decision(
        json.dumps(decision_payload(decision)),
        request=request,
    )
    return replace(normalized, repair_attempted=decision.repair_attempted)


def _manager_repair_fingerprint(raw_text: str) -> str | None:
    """Capture immutable Manager semantics before any model-based reformatting."""
    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    required = {
        "phase",
        "action",
        "expected_plan_revision",
        "expected_work_state_revision",
        "reason",
    }
    if not required.issubset(payload):
        return None
    semantic = {
        "phase": payload.get("phase"),
        "action": payload.get("action"),
        "expected_plan_revision": payload.get("expected_plan_revision"),
        "expected_work_state_revision": payload.get("expected_work_state_revision"),
        "reason": payload.get("reason"),
        "selected_mission_id": payload.get("selected_mission_id"),
        "constraints": payload.get("constraints", []),
        "proposal_sha256": payload.get("proposal_sha256"),
    }
    return json.dumps(semantic, sort_keys=True, ensure_ascii=False)


def _required_revision(payload: dict[str, object], key: str) -> int:
    value = payload.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise RuntimeContractError(f"{key} must be a non-negative integer")
    return value


def _required_text(payload: dict[str, object], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value.strip():
        raise RuntimeContractError(f"{key} must be a non-empty string")
    if len(value) > 8_000:
        raise RuntimeContractError(f"{key} exceeds the bounded Runtime limit")
    return value.strip()


def _string_tuple(value: object, label: str) -> tuple[str, ...]:
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item.strip() for item in value
    ):
        raise RuntimeContractError(f"{label} must be an array of non-empty strings")
    result = tuple(item.strip() for item in value)
    if len(set(result)) != len(result):
        raise RuntimeContractError(f"{label} contains duplicates")
    return result


__all__ = [
    "AdapterDecisionProvider",
    "DecisionProvider",
    "FakeDecisionProvider",
    "ManagerDecisionProposal",
    "ManagerDecisionRequest",
    "ManagerPhase",
    "decision_payload",
    "parse_manager_decision",
    "validate_manager_decision_proposal",
]
