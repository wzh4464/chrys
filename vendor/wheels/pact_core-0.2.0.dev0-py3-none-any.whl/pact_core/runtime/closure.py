"""Pure Campaign closure policy for the multi-Mission R3 slice."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ClosureAssessment:
    completed: bool
    covered_ac_ids: tuple[str, ...]
    gaps: tuple[str, ...]
    reasons: tuple[str, ...]


def evaluate_closure(
    *,
    current_ac_ids: tuple[str, ...],
    evidence_ac_ids: tuple[str, ...],
    mission_statuses: tuple[str, ...],
) -> ClosureAssessment:
    """Require per-AC evidence and a terminal status for every current Mission."""
    covered = tuple(ac_id for ac_id in current_ac_ids if ac_id in evidence_ac_ids)
    gaps = tuple(ac_id for ac_id in current_ac_ids if ac_id not in evidence_ac_ids)
    reasons: list[str] = []
    if gaps:
        reasons.append("acceptance_evidence_missing")
    terminal_mission_statuses = {"completed", "superseded", "abandoned"}
    if any(status not in terminal_mission_statuses for status in mission_statuses):
        reasons.append("missions_not_completed")
    return ClosureAssessment(
        completed=not reasons,
        covered_ac_ids=covered,
        gaps=gaps,
        reasons=tuple(reasons),
    )
