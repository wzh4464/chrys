"""File-backed canonical state store for the single-process R3 demo."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from pact_core.artifacts import atomic_write_text, read_json, write_json_atomic
from pact_core.runtime.planning import (
    InitialPlan,
    MissionDefinition,
    MissionStatus,
    classify_frontier,
    compute_frontier,
    initial_plan_payload,
    plan_revision_missions,
    scheduled_execution,
)
from pact_core.runtime.schemas import (
    EXECUTION_EVIDENCE_SCHEMA,
    LATEST_CAMPAIGN_SCHEMA,
    MANAGER_DECISION_SCHEMA,
    ORIGINAL_INTENT_SCHEMA,
    PLAN_REVISION_SCHEMA,
    PLANNER_PROPOSAL_SCHEMA,
    WORK_STATE_SCHEMA,
    RuntimeStateError,
    StaleWorkStateError,
    goal_contract_criteria,
    validate_goal_contract,
)

_CAMPAIGN_ID_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*\Z")


@dataclass(frozen=True, slots=True)
class CampaignPaths:
    runtime_root: Path
    campaign_dir: Path
    original_intent: Path
    contract_revision: Path
    initial_plan: Path
    plan_revisions: Path
    plan_revision: Path
    manager_decisions: Path
    planner_proposals: Path
    semantic_artifacts: Path
    current_state: Path
    state_revisions: Path
    evidence_dir: Path
    dashboard: Path
    latest: Path


def build_campaign_paths(workspace: Path, campaign_id: str) -> CampaignPaths:
    runtime_root = workspace.expanduser().resolve() / ".pact" / "runtime"
    campaign_dir = runtime_root / "campaigns" / campaign_id
    return CampaignPaths(
        runtime_root=runtime_root,
        campaign_dir=campaign_dir,
        original_intent=campaign_dir / "original-intent.json",
        contract_revision=campaign_dir / "goal-contract-revisions" / "rev-0001.json",
        initial_plan=campaign_dir / "initial-plan.json",
        plan_revisions=campaign_dir / "plan-revisions",
        plan_revision=campaign_dir / "plan-revisions" / "rev-0001.json",
        manager_decisions=campaign_dir / "governance" / "manager-decisions",
        planner_proposals=campaign_dir / "governance" / "planner-proposals",
        semantic_artifacts=campaign_dir / "governance" / "provider-artifacts",
        current_state=campaign_dir / "work-state.json",
        state_revisions=campaign_dir / "work-state-revisions",
        evidence_dir=campaign_dir / "evidence",
        dashboard=campaign_dir / "dashboard.json",
        latest=runtime_root / "latest.json",
    )


class CampaignReader:
    """Read-only access to one Campaign's canonical inputs and current state."""

    def __init__(self, workspace: Path, campaign_id: str) -> None:
        if not _CAMPAIGN_ID_RE.fullmatch(campaign_id):
            raise RuntimeStateError(f"invalid Campaign id: {campaign_id!r}")
        self.workspace = workspace.expanduser().resolve()
        self.campaign_id = campaign_id
        self.paths = build_campaign_paths(self.workspace, campaign_id)

    def read_current_state(self) -> dict[str, object]:
        payload = self._read_object(self.paths.current_state, "canonical Work State")
        if payload.get("schema") != WORK_STATE_SCHEMA:
            raise RuntimeStateError(
                f"unsupported work state schema: {payload.get('schema')!r}"
            )
        if payload.get("campaign_id") != self.campaign_id:
            raise RuntimeStateError("canonical Work State Campaign identity mismatch")
        revision = payload.get("revision")
        if isinstance(revision, bool) or not isinstance(revision, int) or revision < 0:
            raise RuntimeStateError(
                "canonical Work State revision must be a non-negative integer"
            )
        return payload

    def read_contract(self) -> dict[str, object]:
        payload = self._read_object(self.paths.contract_revision, "Goal Contract")
        try:
            normalized = validate_goal_contract(payload)
        except ValueError as exc:
            raise RuntimeStateError(f"invalid persisted Goal Contract: {exc}") from exc
        if payload.get("campaign_id") != self.campaign_id or payload.get("revision") != 1:
            raise RuntimeStateError("persisted Goal Contract identity mismatch")
        return normalized

    def read_plan_revision(self, revision: int | None = None) -> dict[str, object]:
        if revision is None:
            state = self.read_current_state()
            value = state.get("plan_revision")
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise RuntimeStateError("Work State Plan revision must be positive")
            revision = value
        path = self.plan_revision_path(revision)
        payload = self._read_object(path, "Plan Revision")
        if payload.get("schema") != PLAN_REVISION_SCHEMA:
            raise RuntimeStateError(
                f"unsupported Plan Revision schema: {payload.get('schema')!r}"
            )
        if (
            payload.get("campaign_id") != self.campaign_id
            or payload.get("revision") != revision
        ):
            raise RuntimeStateError("persisted Plan Revision identity mismatch")
        missions = payload.get("missions")
        if not isinstance(missions, list) or not missions:
            raise RuntimeStateError("Plan Revision missions must be a non-empty array")
        return payload

    def plan_revision_path(self, revision: int) -> Path:
        if isinstance(revision, bool) or revision < 1:
            raise RuntimeStateError("Plan revision must be a positive integer")
        return self.paths.plan_revisions / f"rev-{revision:04d}.json"

    def mission_plan_path(self, mission_id: str, *, plan_revision: int = 1) -> Path:
        if not _CAMPAIGN_ID_RE.fullmatch(mission_id):
            raise RuntimeStateError(f"invalid Mission id: {mission_id!r}")
        if isinstance(plan_revision, bool) or plan_revision < 1:
            raise RuntimeStateError("Plan revision must be a positive integer")
        return (
            self.paths.plan_revisions
            / f"rev-{plan_revision:04d}-missions"
            / f"{mission_id}.md"
        )

    def relative_ref(self, path: Path) -> str:
        try:
            return path.resolve().relative_to(self.workspace).as_posix()
        except ValueError as exc:
            raise RuntimeStateError(f"Runtime artifact is outside workspace: {path}") from exc

    @staticmethod
    def _read_object(path: Path, label: str) -> dict[str, object]:
        try:
            return read_json(path)
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            raise RuntimeStateError(f"{label} is not valid JSON: {path}") from exc


class _CampaignStore(CampaignReader):
    """Persist one Campaign; the Control Plane owns this private committer."""

    def initialize(
        self,
        contract: dict[str, object],
        *,
        plan: InitialPlan,
    ) -> dict[str, object]:
        """Create immutable inputs and canonical Work State revision 0."""
        if self.paths.campaign_dir.exists():
            raise RuntimeStateError(f"Campaign already exists: {self.campaign_id}")
        normalized = validate_goal_contract(contract)
        created_at = datetime.now(UTC).isoformat()
        criteria = goal_contract_criteria(normalized)
        ac_ids = [criterion["id"] for criterion in criteria]
        plan_refs = {
            mission.id: self.relative_ref(
                self.mission_plan_path(mission.id, plan_revision=1)
            )
            for mission in plan.missions
        }
        canonical_missions = plan_revision_missions(plan, plan_refs=plan_refs)
        original_intent = {
            "schema": ORIGINAL_INTENT_SCHEMA,
            "campaign_id": self.campaign_id,
            "created_at": created_at,
            "goal": normalized["goal"],
            "acceptance_criteria": criteria,
            "non_goals": normalized["non_goals"],
        }
        contract_revision = {
            **normalized,
            "campaign_id": self.campaign_id,
            "revision": 1,
            "created_at": created_at,
        }
        plan_revision = {
            "schema": PLAN_REVISION_SCHEMA,
            "campaign_id": self.campaign_id,
            "revision": 1,
            "parent_revision": None,
            "contract_revision": 1,
            "created_at": created_at,
            "reason": "user_accepted_initial_plan",
            "initial_plan_ref": self.relative_ref(self.paths.initial_plan),
            "constraints": list(plan.constraints),
            "missions": canonical_missions,
            "operations": [
                {"op": "add_mission", "mission_id": mission.id}
                for mission in plan.missions
            ],
            "planner_proposal_ref": None,
            "manager_approval_ref": None,
        }
        statuses: dict[str, MissionStatus] = {
            mission.id: "pending" for mission in plan.missions
        }
        frontier = compute_frontier(plan, statuses)
        selected = frontier[0] if len(frontier) == 1 else None
        state_status, next_action, selection_reason = classify_frontier(frontier)
        state: dict[str, object] = {
            "schema": WORK_STATE_SCHEMA,
            "campaign_id": self.campaign_id,
            "revision": 0,
            "parent_revision": None,
            "status": state_status,
            "contract_revision": 1,
            "contract_ref": self.relative_ref(self.paths.contract_revision),
            "plan_revision": 1,
            "plan_ref": self.relative_ref(self.paths.plan_revision),
            "missions": [
                {
                    "id": mission.id,
                    "status": "active" if mission.id == selected else "pending",
                    "execution_refs": [],
                    "evidence_refs": [],
                }
                for mission in plan.missions
            ],
            "frontier": {
                "eligible": list(frontier),
                "selected": selected,
                "selection_reason": selection_reason,
            },
            "acceptance": {
                "criteria": [
                    {**criterion, "status": "pending", "evidence_refs": []}
                    for criterion in criteria
                ],
                "gaps": ac_ids,
            },
            "execution": scheduled_execution(self.campaign_id, selected),
            "evidence_refs": [],
            "governance": {
                "latest_challenge": None,
                "gap_signature": None,
                "consecutive_no_progress": 0,
                "planner_proposal_ref": None,
                "manager_decision_refs": [],
            },
            "closure": {
                "completed": False,
                "reasons": ["missions_not_completed", "acceptance_evidence_missing"],
            },
            "next_action": next_action,
            "created_at": created_at,
            "updated_at": created_at,
        }

        write_json_atomic(self.paths.original_intent, original_intent)
        write_json_atomic(self.paths.contract_revision, contract_revision)
        write_json_atomic(self.paths.initial_plan, initial_plan_payload(plan))
        for mission in plan.missions:
            atomic_write_text(
                self.mission_plan_path(mission.id, plan_revision=1),
                _build_mission_plan(normalized, mission, plan.constraints),
            )
        write_json_atomic(self.plan_revision_path(1), plan_revision)
        write_json_atomic(self._revision_path(0), state)
        write_json_atomic(self.paths.current_state, state)
        write_json_atomic(
            self.paths.latest,
            {
                "schema": LATEST_CAMPAIGN_SCHEMA,
                "campaign_id": self.campaign_id,
                "updated_at": created_at,
            },
        )
        return state

    def commit_work_state(
        self,
        *,
        expected_revision: int,
        next_state: dict[str, object],
    ) -> dict[str, object]:
        """Atomically replace canonical state only when its revision still matches."""
        current = self.read_current_state()
        actual_revision = current["revision"]
        if actual_revision != expected_revision:
            raise StaleWorkStateError(
                f"expected revision {expected_revision}, found {actual_revision}"
            )
        revision = expected_revision + 1
        committed = dict(next_state)
        committed.update(
            {
                "schema": WORK_STATE_SCHEMA,
                "campaign_id": self.campaign_id,
                "revision": revision,
                "parent_revision": expected_revision,
                "updated_at": datetime.now(UTC).isoformat(),
            }
        )
        revision_path = self._revision_path(revision)
        if revision_path.exists():
            raise RuntimeStateError(f"Work State revision already exists: {revision}")
        write_json_atomic(revision_path, committed)
        write_json_atomic(self.paths.current_state, committed)
        return committed

    def assert_expected_revision(self, expected_revision: int) -> None:
        """Fail closed before an external effect when the canonical head moved."""
        actual_revision = self.read_current_state()["revision"]
        if actual_revision != expected_revision:
            raise StaleWorkStateError(
                f"expected revision {expected_revision}, found {actual_revision}"
            )

    def write_execution_evidence(self, payload: dict[str, object]) -> str:
        """Append one immutable Kernel evidence record and return its workspace ref."""
        loop_id = payload.get("execution_loop_id")
        if not isinstance(loop_id, str) or not loop_id:
            raise RuntimeStateError("execution evidence requires execution_loop_id")
        evidence_path = self.paths.evidence_dir / f"{loop_id}.json"
        if evidence_path.exists():
            raise RuntimeStateError(f"execution evidence already exists: {loop_id}")
        record: dict[str, object] = {
            "schema": EXECUTION_EVIDENCE_SCHEMA,
            "campaign_id": self.campaign_id,
            **payload,
        }
        write_json_atomic(evidence_path, record)
        return self.relative_ref(evidence_path)

    def write_manager_decision(
        self,
        payload: dict[str, object],
        *,
        work_state_revision: int,
        phase: str,
        rationale: str,
    ) -> str:
        """Persist one immutable Manager proposal and human-readable rationale."""
        base = self.paths.manager_decisions / (
            f"state-{work_state_revision:06d}-{phase}"
        )
        artifact = base.with_suffix(".json")
        if artifact.exists():
            raise RuntimeStateError("Manager decision artifact already exists")
        record: dict[str, object] = {
            "schema": MANAGER_DECISION_SCHEMA,
            "campaign_id": self.campaign_id,
            "created_at": datetime.now(UTC).isoformat(),
            "proposal": payload,
            "rationale_ref": self.relative_ref(base.with_suffix(".md")),
        }
        atomic_write_text(base.with_suffix(".md"), rationale.strip() + "\n")
        write_json_atomic(artifact, record)
        return self.relative_ref(artifact)

    def write_planner_proposal(
        self,
        payload: dict[str, object],
        *,
        proposed_revision: int,
        rationale: str,
    ) -> str:
        """Persist one immutable Planner proposal independently from approval."""
        base = self.paths.planner_proposals / f"rev-{proposed_revision:04d}"
        artifact = base.with_suffix(".json")
        if artifact.exists():
            raise RuntimeStateError("Planner proposal artifact already exists")
        record = {
            "schema": PLANNER_PROPOSAL_SCHEMA,
            "campaign_id": self.campaign_id,
            "proposed_revision": proposed_revision,
            "created_at": datetime.now(UTC).isoformat(),
            "proposal": payload,
            "rationale_ref": self.relative_ref(base.with_suffix(".md")),
        }
        atomic_write_text(base.with_suffix(".md"), rationale.strip() + "\n")
        write_json_atomic(artifact, record)
        return self.relative_ref(artifact)

    def write_plan_revision(
        self,
        *,
        expected_work_state_revision: int,
        expected_plan_revision: int,
        plan: InitialPlan,
        reason: str,
        operations: tuple[dict[str, object], ...],
        planner_proposal_ref: str,
        manager_approval_ref: str,
    ) -> str:
        """Write an approved immutable Plan snapshot after stale-state checks."""
        self.assert_expected_revision(expected_work_state_revision)
        state = self.read_current_state()
        if state.get("plan_revision") != expected_plan_revision:
            raise StaleWorkStateError(
                f"expected Plan revision {expected_plan_revision}, "
                f"found {state.get('plan_revision')!r}"
            )
        revision = expected_plan_revision + 1
        path = self.plan_revision_path(revision)
        if path.exists():
            raise RuntimeStateError(f"Plan Revision already exists: {revision}")
        plan_refs = {
            mission.id: self.relative_ref(
                self.mission_plan_path(mission.id, plan_revision=revision)
            )
            for mission in plan.missions
        }
        contract = self.read_contract()
        for mission in plan.missions:
            atomic_write_text(
                self.mission_plan_path(mission.id, plan_revision=revision),
                _build_mission_plan(contract, mission, plan.constraints),
            )
        record = {
            "schema": PLAN_REVISION_SCHEMA,
            "campaign_id": self.campaign_id,
            "revision": revision,
            "parent_revision": expected_plan_revision,
            "contract_revision": 1,
            "created_at": datetime.now(UTC).isoformat(),
            "reason": reason,
            "initial_plan_ref": self.relative_ref(self.paths.initial_plan),
            "constraints": list(plan.constraints),
            "missions": plan_revision_missions(plan, plan_refs=plan_refs),
            "operations": [dict(operation) for operation in operations],
            "planner_proposal_ref": planner_proposal_ref,
            "manager_approval_ref": manager_approval_ref,
        }
        write_json_atomic(path, record)
        return self.relative_ref(path)

    def _revision_path(self, revision: int) -> Path:
        return self.paths.state_revisions / f"rev-{revision:06d}.json"


def _build_mission_plan(
    contract: dict[str, object],
    mission: MissionDefinition,
    constraints: tuple[str, ...],
) -> str:
    criteria_by_id = {
        criterion["id"]: criterion for criterion in goal_contract_criteria(contract)
    }
    non_goals = contract["non_goals"]
    assert isinstance(non_goals, list)
    constraint_lines = "\n".join(f"- {value}" for value in constraints) or "- None"
    dependency_lines = (
        "\n".join(f"- {value}" for value in mission.dependencies) or "- None"
    )
    return (
        f"# Runtime Mission: {mission.id}\n\n"
        f"## Campaign Goal\n\n{contract['goal']}\n\n"
        f"## Mission Objective\n\n{mission.objective}\n\n"
        "## Target Acceptance Criteria\n\n"
        + "\n".join(
            f"- {ac_id}: {criteria_by_id[ac_id]['text']}"
            for ac_id in mission.target_ac_ids
        )
        + "\n\n## Dependencies\n\n"
        + dependency_lines
        + "\n\n## Verification Intent\n\n"
        + mission.verification_intent
        + "\n\n## Plan Constraints\n\n"
        + constraint_lines
        + "\n\n## Non-goals\n\n"
        + "\n".join(f"- {value}" for value in non_goals)
        + "\n"
    )


__all__ = [
    "CampaignPaths",
    "CampaignReader",
    "RuntimeStateError",
    "StaleWorkStateError",
    "build_campaign_paths",
]
