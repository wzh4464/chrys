const byId = (id) => document.getElementById(id);

let lastProjectionFingerprint = "";
let refreshInFlight = false;

const STATUS_LABELS = Object.freeze({
  abandoned: "已放弃",
  active: "进行中",
  applied: "已应用",
  blocked: "已阻塞",
  complete: "完成",
  completed: "已完成",
  corrupt: "已损坏",
  failed: "失败",
  missing: "缺失",
  none: "无",
  no_changes: "无变更",
  not_claimed: "未声明",
  not_configured: "未配置",
  passed: "通过",
  pending: "等待中",
  ready: "就绪",
  running: "运行中",
  satisfied: "已满足",
  succeeded: "成功",
  superseded: "已替代",
  unavailable: "不可用",
  valid: "有效",
});

const STAGE_LABELS = Object.freeze({
  checkpoint: "检查点",
  final_validation: "最终验证",
  gate: "终止判定",
  promotion: "结果应用",
  public_verification: "公开验证",
  reviewer: "独立审查",
  reviewer_turn: "Reviewer 审查",
  review_decision: "审查结论",
  worker: "任务执行",
  worker_done: "Worker 完成提议",
  worker_turn: "Worker 执行",
  loop_end: "执行结束",
  loop_initialized: "执行初始化",
  round_start: "轮次开始",
  verification: "确定性验证",
});

const ROLE_LABELS = Object.freeze({
  manager: "裁决者 Manager",
  planner: "规划者 Planner",
  reviewer: "审查者 Reviewer",
  worker: "执行者 Worker",
});

const SELECTION_LABELS = Object.freeze({
  campaign_complete: "Campaign 已完成",
  execution_blocked: "执行已阻塞",
  manager_reasoned_retry: "Manager 决定重试",
  manager_selected_frontier: "Manager 已选择推进任务",
  no_eligible_mission: "无可推进任务",
  selected: "已选择任务",
  single_eligible_mission: "唯一可推进任务",
  unclassified: "未分类",
});

const ACTION_LABELS = Object.freeze({
  approve_plan: "批准计划",
  block: "阻塞 Campaign",
  execute_mission: "执行当前任务",
  manager_decide: "等待 Manager 决策",
  no_progress_observation: "无进展观察",
  none: "无",
  post_evidence_replan_unsupported: "证据回写后无法重新规划",
  reject_plan: "拒绝计划",
  replan: "重新规划",
  request_replan: "请求重新规划",
  request_revision: "请求修改计划",
  request_user: "请求用户决策",
  retry: "重试当前任务",
  review_plan: "审核计划",
  reviewer_plan_challenge: "Reviewer 计划质疑",
  route: "路线裁决",
  select: "选择任务",
});

const OPERATION_LABELS = Object.freeze({
  add_mission: "新增任务",
  supersede_mission: "替代任务",
});

const ARTIFACT_LABELS = Object.freeze({
  checkpoint: "检查点",
  events: "事件流",
  execution_state: "执行状态",
  final_patch: "最终补丁",
  final_validation: "最终验证",
  gate_decision: "终止判定",
  initialization: "初始化",
  manifest: "清单",
  promotion: "结果应用",
  review_decision: "审查结论",
  reviewer_result: "Reviewer 结果",
  state: "状态",
  verification: "验证结果",
  worker_result: "Worker 结果",
});

function translated(value, labels) {
  if (value === undefined || value === null || value === "") return "无";
  return labels[value] || String(value);
}

function statusLabel(value) {
  return translated(value, STATUS_LABELS);
}

function stageLabel(value) {
  const stage = translated(value, STAGE_LABELS);
  return stage === String(value) ? statusLabel(value) : stage;
}

function roleLabel(value) {
  return translated(value, ROLE_LABELS);
}

function actionLabel(value) {
  return translated(value, ACTION_LABELS);
}

function goalSummary(goal) {
  const text = String(goal || "").trim();
  if (!text) return "尚未记录目标";
  return text.split(/\n\s*\n/, 1)[0].replace(/^#+\s*/gm, "").trim();
}

function node(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined && text !== null) element.textContent = String(text);
  return element;
}

function clear(target) {
  target.replaceChildren();
}

function projectionFingerprint(data) {
  return JSON.stringify({ ...data, generated_at: null });
}

function captureInteractionState() {
  const details = byId("overview-panel").querySelector("details.goal-details");
  const timeline = byId("timeline-panel").querySelector(".timeline");
  return {
    goalExpanded: Boolean(details && details.open),
    timelineScrollTop: timeline ? timeline.scrollTop : null,
    timelineWasAtEnd: Boolean(
      timeline
      && timeline.scrollHeight > timeline.clientHeight
      && timeline.scrollHeight - timeline.clientHeight - timeline.scrollTop <= 8
    ),
  };
}

function restoreInteractionState(state) {
  const details = byId("overview-panel").querySelector("details.goal-details");
  if (details) details.open = state.goalExpanded;

  const timeline = byId("timeline-panel").querySelector(".timeline");
  if (!timeline || state.timelineScrollTop === null) return;
  if (state.timelineWasAtEnd) {
    timeline.scrollTop = timeline.scrollHeight;
    return;
  }
  const maximum = Math.max(0, timeline.scrollHeight - timeline.clientHeight);
  timeline.scrollTop = Math.min(state.timelineScrollTop, maximum);
}

function heading(target, text) {
  target.append(node("h2", "", text));
}

function chip(text, tone = "") {
  return node("span", `chip ${tone}`, text);
}

function tone(status) {
  if (["approve_plan", "complete", "completed", "passed", "ready", "select", "succeeded", "satisfied", "applied", "no_changes"].includes(status)) return "good";
  if (["block", "blocked", "corrupt", "failed", "reject_plan"].includes(status)) return "bad";
  return "warn";
}

function renderOverview(data) {
  const target = byId("overview-panel");
  clear(target); heading(target, "工作单元与目标");
  const layout = node("div", "overview-grid");
  const copy = node("div", "overview-copy");
  const summary = goalSummary(data.overview.goal);
  copy.append(node("p", "goal", summary));
  if (summary !== String(data.overview.goal || "").trim()) {
    const details = node("details", "goal-details");
    details.append(node("summary", "", "查看完整目标"));
    details.append(node("pre", "goal-full", data.overview.goal));
    copy.append(details);
  }
  const next = node("div", "next-action");
  next.append(node("strong", "", "下一步可执行动作"));
  next.append(node("span", "", actionLabel(data.overview.next_action)));
  copy.append(next);

  const current = node("aside", "overview-status");
  current.append(node("h3", "", "当前状态"));
  const row = node("div", "status-row");
  row.append(chip(statusLabel(data.overview.status), tone(data.overview.status)));
  row.append(chip(`工作状态 r${data.overview.work_state_revision}`));
  row.append(chip(`计划 r${data.overview.plan_revision}`));
  row.append(chip(`目标合同 r${data.overview.contract_revision}`));
  current.append(row);
  current.append(node("p", "overview-id", `Campaign ID · ${data.overview.campaign_id}`));
  layout.append(copy, current);
  target.append(layout);
}

function refList(values) {
  return (values || []).length ? values.join(", ") : "—";
}

function renderMissions(data) {
  const target = byId("mission-panel");
  clear(target); heading(target, "任务图与推进前沿（Mission / Frontier）");
  const frontier = node("div", "status-row frontier-row");
  frontier.append(chip(`可推进：${refList(data.frontier.eligible)}`));
  frontier.append(chip(`当前选择：${data.frontier.selected || "无"}`));
  frontier.append(chip(translated(data.frontier.selection_reason || "unclassified", SELECTION_LABELS)));
  target.append(frontier);
  const graph = node("div", "mission-grid");
  for (const mission of data.missions) {
    const card = node("article", `mission-card ${mission.status}`);
    const title = node("div", "mission-title");
    title.append(node("strong", "", mission.id));
    title.append(chip(statusLabel(mission.status), tone(mission.status)));
    card.append(title);
    card.append(node("p", "mission-objective", mission.objective));
    const list = node("dl", "kv compact");
    const rows = [
      ["目标验收条件", refList(mission.target_ac_ids)],
      ["依赖任务", refList(mission.dependencies)],
      ["后续任务", refList(mission.successors)],
      ["替代任务", refList(mission.supersedes)],
      ["证据", refList(mission.evidence_refs)],
    ];
    for (const [key, value] of rows) { list.append(node("dt", "", key)); list.append(node("dd", "", value)); }
    card.append(list); graph.append(card);
  }
  target.append(graph);
}

function operationText(operation) {
  const replacements = operation.replacement_mission_ids || [];
  return replacements.length
    ? `${translated(operation.op, OPERATION_LABELS)} · ${operation.mission_id} → ${replacements.join(", ")}`
    : `${translated(operation.op, OPERATION_LABELS)} · ${operation.mission_id}`;
}

function renderGovernance(data) {
  const target = byId("governance-panel");
  clear(target); heading(target, "受控计划演进");
  const summary = node("div", "status-row");
  summary.append(chip(`触发原因：${actionLabel(data.governance.trigger)}`));
  summary.append(chip(`同一 gap 连续次数：${data.governance.consecutive_no_progress}`));
  summary.append(chip(`当前 gap：${data.governance.gap_signature || "无"}`));
  target.append(summary);
  const columns = node("div", "governance-grid");

  const challenge = node("article", "governance-card");
  challenge.append(node("h3", "", "Reviewer 计划质疑"));
  if (data.governance.latest_challenge) {
    challenge.append(node("p", "primary-small", data.governance.latest_challenge.reason));
    challenge.append(chip(actionLabel(data.governance.latest_challenge.recommended_action)));
    challenge.append(node("p", "secondary mono", data.governance.latest_challenge.gap_signature));
  } else challenge.append(node("p", "secondary", "尚未记录结构化计划质疑。"));
  columns.append(challenge);

  const planner = node("article", "governance-card");
  planner.append(node("h3", "", "Planner 计划提案"));
  if (data.governance.planner_proposal) {
    planner.append(node("p", "primary-small", data.governance.planner_proposal.reason));
    for (const operation of data.governance.planner_proposal.operations) planner.append(node("div", "operation", operationText(operation)));
    planner.append(node("p", "secondary mono", data.governance.planner_proposal.ref));
  } else planner.append(node("p", "secondary", "尚未记录 Plan Revision 提案。"));
  columns.append(planner);

  const manager = node("article", "governance-card");
  manager.append(node("h3", "", "Manager 决策"));
  if (data.governance.manager_decisions.length) {
    for (const decision of data.governance.manager_decisions) {
      const item = node("div", "decision");
      const line = node("div", "decision-title");
      line.append(chip(actionLabel(decision.phase))); line.append(chip(actionLabel(decision.action), tone(decision.action)));
      item.append(line); item.append(node("p", "secondary", decision.reason));
      manager.append(item);
    }
  } else manager.append(node("p", "secondary", "尚未记录 Manager 决策。"));
  columns.append(manager);
  target.append(columns);
  if (data.governance.block_reason) target.append(chip(`阻塞原因：${data.governance.block_reason}`, "bad"));
}

function renderPipeline(data) {
  const target = byId("pipeline-panel");
  clear(target); heading(target, `执行流水线 · ${stageLabel(data.pipeline.current_stage)}`);
  const pipeline = node("div", "pipeline");
  for (const stage of data.pipeline.stages) {
    const item = node("div", `stage ${stage.status}`);
    item.append(node("div", "stage-name", stageLabel(stage.id)));
    item.append(node("div", "stage-detail", statusLabel(stage.detail || stage.status)));
    pipeline.append(item);
  }
  target.append(pipeline);
}

function renderAcceptance(data) {
  const target = byId("acceptance-panel");
  clear(target); heading(target, "验收条件与证据");
  for (const criterion of data.acceptance.criteria) {
    const item = node("div", `criterion ${criterion.status}`);
    item.append(node("div", "criterion-mark", criterion.status === "satisfied" ? "✓" : "○"));
    const copy = node("div");
    copy.append(node("div", "criterion-id", criterion.id));
    copy.append(node("div", "criterion-text", criterion.text));
    item.append(copy); target.append(item);
  }
  if (data.acceptance.gaps.length) target.append(chip(`未满足：${data.acceptance.gaps.join(", ")}`, "bad"));
  else target.append(chip("当前所有验收条件均有证据", "good"));
}

function renderTimeline(data) {
  const target = byId("timeline-panel");
  clear(target); heading(target, `执行时间线 · ${statusLabel(data.timeline.availability)}`);
  const timeline = node("div", "timeline");
  for (const event of data.timeline.items) {
    const item = node("div", "event");
    item.append(node("span", "event-seq", String(event.seq).padStart(2, "0")));
    item.append(node("span", "", stageLabel(event.operation || event.event)));
    item.append(node("span", "event-meta", [event.role && roleLabel(event.role), event.status && statusLabel(event.status), event.round && `第 ${event.round} 轮`].filter(Boolean).join(" · ")));
    timeline.append(item);
  }
  if (!data.timeline.items.length) timeline.append(node("p", "secondary", "尚无执行事件。"));
  target.append(timeline);
}

function renderProvenance(data) {
  const target = byId("provenance-panel");
  clear(target); heading(target, "角色与来源追踪");
  const actors = node("div", "actors");
  for (const actor of data.actors) {
    const card = node("article", "actor");
    const title = node("div", "actor-title");
    title.append(node("strong", "", roleLabel(actor.role))); title.append(chip(statusLabel(actor.status), tone(actor.status)));
    card.append(title);
    const list = node("dl", "kv");
    const rows = [
      ["适配器", actor.adapter_id], ["模型", actor.model], ["Session", actor.session_id || "不可用"],
      ["原生轨迹存储", actor.native_store_ref || "不可用"], ["事件", actor.normalized_events_ref || "不可用"],
      ["恢复 / 重放", `${statusLabel(actor.capabilities.resume)} / ${statusLabel(actor.capabilities.replay)}`],
    ];
    for (const [key, value] of rows) { list.append(node("dt", "", key)); list.append(node("dd", "", value)); }
    card.append(list); card.append(node("p", "secondary", actor.limitation)); actors.append(card);
  }
  target.append(actors);
  const refs = node("div", "refs");
  for (const artifact of data.artifacts) refs.append(node("span", "ref", `${translated(artifact.kind, ARTIFACT_LABELS)} · ${artifact.ref}`));
  target.append(refs);
}

function render(data) {
  byId("generated-at").textContent = data.generated_at ? `视图生成时间 ${data.generated_at}` : "";
  if (data.availability !== "ready") {
    byId("dashboard").hidden = true; byId("empty-state").hidden = false;
    byId("connection-state").textContent = `视图状态：${statusLabel(data.availability)}`;
    return;
  }
  byId("empty-state").hidden = true; byId("dashboard").hidden = false;
  byId("connection-state").textContent = "视图实时更新中";
  renderOverview(data); renderMissions(data); renderGovernance(data); renderPipeline(data);
  renderAcceptance(data); renderTimeline(data); renderProvenance(data);
}

async function refresh() {
  if (refreshInFlight) return;
  refreshInFlight = true;
  try {
    const response = await fetch("/api/projection", { cache: "no-store" });
    const data = await response.json();
    const fingerprint = projectionFingerprint(data);
    if (fingerprint === lastProjectionFingerprint) return;
    const interactionState = captureInteractionState();
    render(data);
    restoreInteractionState(interactionState);
    lastProjectionFingerprint = fingerprint;
  } catch (_) {
    // Force recovery to render once even if the canonical projection is unchanged.
    lastProjectionFingerprint = "";
    byId("connection-state").textContent = "视图不可用";
  } finally {
    refreshInFlight = false;
  }
}

refresh();
setInterval(refresh, 800);
