"""Read-only, rebuildable Dashboard projection over canonical Runtime state."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath

from pact_core.artifacts import build_loop_paths, read_json, round_paths, write_json_atomic
from pact_core.runtime.schemas import (
    DASHBOARD_PROJECTION_SCHEMA,
    EXECUTION_EVIDENCE_SCHEMA,
    MANAGER_DECISION_SCHEMA,
    MANAGER_DECISION_PROPOSAL_SCHEMA,
    PLAN_REVISION_PROPOSAL_SCHEMA,
    PLANNER_PROPOSAL_SCHEMA,
)
from pact_core.runtime.store import CampaignReader
from pact_core.schemas import (
    EVENT_SCHEMA,
    MANIFEST_SCHEMA,
    ROLE_RESULT_SCHEMA,
    STATE_SCHEMA,
)

_PIPELINE_OPERATIONS = (
    ("worker", "worker_turn"),
    ("checkpoint", "checkpoint"),
    ("verification", "public_verification"),
    ("reviewer", "reviewer_turn"),
    ("gate", "gate"),
    ("promotion", "promotion"),
)


def build_dashboard_projection(reader: CampaignReader) -> dict[str, object]:
    """Build a bounded operator view from canonical state and explicit refs."""
    state = reader.read_current_state()
    contract = reader.read_contract()
    plan_revision = reader.read_plan_revision()
    execution = _required_object(state, "execution")
    acceptance = _required_object(state, "acceptance")
    frontier = _required_object(state, "frontier")
    closure = _required_object(state, "closure")
    missions = _mission_projection(state, plan_revision)
    loop_id = _required_str(execution, "loop_id")
    loop_paths = build_loop_paths(reader.workspace, loop_id)
    loop_state = _optional_json(loop_paths.state, STATE_SCHEMA)
    current_round = _non_negative_int(loop_state.get("current_round")) if loop_state else 0
    current_round_paths = round_paths(loop_paths.loop_dir, current_round) if current_round else None
    events, timeline_availability = _read_event_projection(loop_paths.events)
    evidence_records = _read_evidence_records(reader, state)
    evidence = evidence_records[-1][1] if evidence_records else None
    artifact_refs = _artifact_refs(
        reader,
        loop_id=loop_id,
        loop_state=loop_state,
        current_round=current_round,
        evidence=evidence,
    )
    manifest = _optional_json(loop_paths.manifest, MANIFEST_SCHEMA)
    actors = [
        _actor_projection(
            reader,
            role=role,
            loop_id=loop_id,
            role_result_path=(
                getattr(current_round_paths, f"{role}_result")
                if current_round_paths is not None
                else None
            ),
            manifest=manifest,
            loop_state=loop_state,
        )
        for role in ("worker", "reviewer")
    ]
    pipeline = _pipeline_projection(events, state, loop_state)
    criteria = acceptance.get("criteria")
    gaps = acceptance.get("gaps")
    if not isinstance(criteria, list) or not isinstance(gaps, list):
        criteria, gaps = [], []
    evidence_refs = [
        ref for ref in _string_list(state.get("evidence_refs"))
        if _safe_relative_ref(ref)
    ]
    revision = state.get("revision")
    if isinstance(revision, bool) or not isinstance(revision, int):
        revision = 0
    governance = _governance_projection(
        reader,
        state=state,
        plan_revision=plan_revision,
        evidence_records=evidence_records,
    )
    return {
        "schema": DASHBOARD_PROJECTION_SCHEMA,
        "projection_is_writable": False,
        "availability": "ready",
        "generated_at": datetime.now(UTC).isoformat(),
        "source": {
            "work_state_ref": reader.relative_ref(reader.paths.current_state),
            "work_state_revision": revision,
            "contract_ref": _safe_ref(state.get("contract_ref")),
            "plan_ref": _safe_ref(state.get("plan_ref")),
            "plan_revision": state.get("plan_revision"),
            "evidence_refs": evidence_refs,
        },
        "overview": {
            "campaign_id": reader.campaign_id,
            "status": state.get("status"),
            "work_state_revision": revision,
            "contract_revision": state.get("contract_revision", 1),
            "plan_revision": state.get("plan_revision"),
            "goal": _bounded_text(contract.get("goal"), limit=2_000),
            "next_action": state.get("next_action"),
        },
        "missions": missions,
        "frontier": {
            "eligible": _string_list(frontier.get("eligible")),
            "selected": frontier.get("selected"),
            "selection_reason": frontier.get("selection_reason"),
        },
        "governance": governance,
        "pipeline": pipeline,
        "acceptance": {
            "criteria": _safe_criteria(criteria),
            "gaps": [value for value in gaps if isinstance(value, str)],
            "closure_completed": closure.get("completed") is True,
            "closure_reasons": _string_list(closure.get("reasons")),
        },
        "timeline": {
            "availability": timeline_availability,
            "items": [_timeline_item(event) for event in events[-32:]],
        },
        "artifacts": artifact_refs,
        "actors": actors,
    }


def write_dashboard_projection(reader: CampaignReader) -> dict[str, object]:
    """Atomically refresh the derived projection; never mutate canonical state."""
    projection = build_dashboard_projection(reader)
    existing = _optional_json(reader.paths.dashboard, DASHBOARD_PROJECTION_SCHEMA)
    if existing is not None and _without_generated_at(existing) == _without_generated_at(
        projection
    ):
        return existing
    write_json_atomic(reader.paths.dashboard, projection)
    return projection


def empty_dashboard_projection(
    *, availability: str = "empty", campaign_id: str | None = None
) -> dict[str, object]:
    """Return the versioned empty/error envelope used by the read-only server."""
    return {
        "schema": DASHBOARD_PROJECTION_SCHEMA,
        "projection_is_writable": False,
        "availability": availability,
        "campaign_id": campaign_id,
        "generated_at": datetime.now(UTC).isoformat(),
    }


def _read_evidence_records(
    reader: CampaignReader, state: dict[str, object]
) -> list[tuple[str, dict[str, object]]]:
    refs = _string_list(state.get("evidence_refs"))
    records: list[tuple[str, dict[str, object]]] = []
    for ref in refs:
        path = _resolve_workspace_ref(reader.workspace, ref)
        payload = _optional_json(path, EXECUTION_EVIDENCE_SCHEMA) if path else None
        if payload is not None:
            records.append((ref, payload))
    return records


def _governance_projection(
    reader: CampaignReader,
    *,
    state: dict[str, object],
    plan_revision: dict[str, object],
    evidence_records: list[tuple[str, dict[str, object]]],
) -> dict[str, object]:
    governance = _required_object(state, "governance")
    challenge = _safe_challenge(governance.get("latest_challenge"), evidence_ref=None)
    if challenge is None:
        for evidence_ref, evidence in reversed(evidence_records):
            challenge = _safe_challenge(
                evidence.get("plan_challenge"), evidence_ref=evidence_ref
            )
            if challenge is not None:
                break
    planner_ref = governance.get("planner_proposal_ref")
    planner = _planner_projection(
        reader, planner_ref if isinstance(planner_ref, str) else None
    )
    manager_decisions = [
        decision
        for ref in _string_list(governance.get("manager_decision_refs"))
        if (decision := _manager_decision_projection(reader, ref)) is not None
    ]
    return {
        "trigger": governance.get("trigger"),
        "block_reason": _bounded_text(governance.get("block_reason")),
        "gap_signature": _bounded_text(governance.get("gap_signature"), limit=240),
        "consecutive_no_progress": _non_negative_int(
            governance.get("consecutive_no_progress")
        ),
        "latest_challenge": challenge,
        "planner_proposal": planner,
        "manager_decisions": manager_decisions,
        "plan_revision": {
            "revision": plan_revision.get("revision"),
            "parent_revision": plan_revision.get("parent_revision"),
            "reason": _bounded_text(plan_revision.get("reason")),
            "operations": _safe_operations(plan_revision.get("operations")),
            "planner_proposal_ref": _safe_ref(
                plan_revision.get("planner_proposal_ref")
            ),
            "manager_approval_ref": _safe_ref(
                plan_revision.get("manager_approval_ref")
            ),
        },
    }


def _planner_projection(
    reader: CampaignReader, ref: str | None
) -> dict[str, object] | None:
    if ref is None:
        return None
    path = _resolve_workspace_ref(reader.workspace, ref)
    record = _optional_json(path, PLANNER_PROPOSAL_SCHEMA) if path else None
    proposal = record.get("proposal") if record else None
    if not isinstance(proposal, dict) or proposal.get("schema") != PLAN_REVISION_PROPOSAL_SCHEMA:
        return None
    missions = proposal.get("missions")
    mission_ids = [
        item.get("id")
        for item in missions
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    ] if isinstance(missions, list) else []
    return {
        "ref": ref,
        "parent_plan_revision": proposal.get("parent_plan_revision"),
        "input_work_state_revision": proposal.get("input_work_state_revision"),
        "reason": _bounded_text(proposal.get("reason")),
        "operations": _safe_operations(proposal.get("operations")),
        "affected_mission_ids": _string_list(proposal.get("affected_mission_ids")),
        "affected_ac_ids": _string_list(proposal.get("affected_ac_ids")),
        "mission_ids": mission_ids,
    }


def _manager_decision_projection(
    reader: CampaignReader, ref: str
) -> dict[str, object] | None:
    path = _resolve_workspace_ref(reader.workspace, ref)
    record = _optional_json(path, MANAGER_DECISION_SCHEMA) if path else None
    proposal = record.get("proposal") if record else None
    if (
        not isinstance(proposal, dict)
        or proposal.get("schema") != MANAGER_DECISION_PROPOSAL_SCHEMA
    ):
        return None
    return {
        "ref": ref,
        "phase": proposal.get("phase"),
        "action": proposal.get("action"),
        "expected_plan_revision": proposal.get("expected_plan_revision"),
        "expected_work_state_revision": proposal.get("expected_work_state_revision"),
        "reason": _bounded_text(proposal.get("reason")),
        "selected_mission_id": proposal.get("selected_mission_id"),
        "constraints": _bounded_string_list(proposal.get("constraints")),
        "proposal_sha256": _bounded_text(proposal.get("proposal_sha256"), limit=128),
    }


def _safe_challenge(
    value: object, *, evidence_ref: str | None
) -> dict[str, object] | None:
    if not isinstance(value, dict):
        return None
    reason = _bounded_text(value.get("reason"))
    signature = value.get("gap_signature")
    action = value.get("recommended_action")
    if reason is None or not isinstance(signature, str) or not isinstance(action, str):
        return None
    return {
        "reason": reason,
        "gap_signature": signature,
        "recommended_action": action,
        "evidence_ref": evidence_ref,
    }


def _safe_operations(value: object) -> list[dict[str, object]]:
    if not isinstance(value, list):
        return []
    safe: list[dict[str, object]] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        op = item.get("op")
        mission_id = item.get("mission_id")
        if not isinstance(op, str) or not isinstance(mission_id, str):
            continue
        record: dict[str, object] = {"op": op, "mission_id": mission_id}
        replacements = item.get("replacement_mission_ids")
        if isinstance(replacements, list):
            record["replacement_mission_ids"] = _string_list(replacements)
        safe.append(record)
    return safe


def _safe_ref(value: object) -> str | None:
    return value if isinstance(value, str) and _safe_relative_ref(value) else None


def _bounded_text(value: object, *, limit: int = 480) -> str | None:
    if not isinstance(value, str):
        return None
    return value if len(value) <= limit else value[: limit - 1] + "…"


def _bounded_string_list(
    value: object, *, item_limit: int = 240, count_limit: int = 16
) -> list[str]:
    return [
        bounded
        for item in _string_list(value)[:count_limit]
        if (bounded := _bounded_text(item, limit=item_limit)) is not None
    ]


def _artifact_refs(
    reader: CampaignReader,
    *,
    loop_id: str,
    loop_state: dict[str, object] | None,
    current_round: int,
    evidence: dict[str, object] | None,
) -> list[dict[str, str]]:
    refs: dict[str, str] = {}
    artifact_values = evidence.get("artifact_refs") if evidence else None
    if isinstance(artifact_values, dict):
        for kind, value in artifact_values.items():
            if isinstance(kind, str) and isinstance(value, str) and _safe_relative_ref(value):
                refs[kind] = value
    loop_paths = build_loop_paths(reader.workspace, loop_id)
    known: dict[str, Path] = {
        "manifest": loop_paths.manifest,
        "execution_state": loop_paths.state,
        "events": loop_paths.events,
        "final_validation": loop_paths.final_validation,
        "promotion": loop_paths.promotion,
    }
    if current_round:
        rpaths = round_paths(loop_paths.loop_dir, current_round)
        known.update(
            {
                "worker_result": rpaths.worker_result,
                "checkpoint": rpaths.checkpoint,
                "verification": rpaths.verification,
                "reviewer_result": rpaths.reviewer_result,
                "gate_decision": rpaths.gate,
            }
        )
    for kind, path in known.items():
        if path.is_file():
            refs.setdefault(kind, reader.relative_ref(path))
    if loop_state is None:
        refs.pop("execution_state", None)
    return [{"kind": kind, "ref": ref} for kind, ref in sorted(refs.items())]


def _pipeline_projection(
    events: list[dict[str, object]],
    state: dict[str, object],
    loop_state: dict[str, object] | None,
) -> dict[str, object]:
    stages: list[dict[str, object]] = []
    for stage_id, operation in _PIPELINE_OPERATIONS:
        status = "pending"
        detail = ""
        for event in events:
            if event.get("event") == "operation_started" and event.get("operation") == operation:
                status = "running"
            elif event.get("event") == "operation_finished" and event.get("operation") == operation:
                status = "succeeded" if event.get("status") == "succeeded" else "failed"
            if stage_id == "verification" and event.get("event") == "verification":
                detail = str(event.get("status") or "")
                if detail not in {"passed", "unavailable"}:
                    status = "blocked"
            elif stage_id == "reviewer" and event.get("event") == "reviewer_skipped":
                status, detail = "skipped", "no usable worker output or delta"
            elif stage_id == "reviewer" and event.get("event") == "reviewer_done":
                detail = str(event.get("status") or "")
            elif stage_id == "gate" and event.get("event") == "gate":
                detail = str(event.get("status") or "")
                if detail != "complete":
                    status = "blocked"
            elif stage_id == "promotion" and event.get("event") == "loop_end":
                promotion = str(event.get("promotion") or "")
                if promotion in {"applied", "no_changes"}:
                    status = "succeeded"
                elif promotion in {"blocked", "failed"}:
                    status = "blocked"
                detail = promotion
        stages.append({"id": stage_id, "status": status, "detail": detail})
    running = next((stage["id"] for stage in stages if stage["status"] == "running"), None)
    current = running or next(
        (stage["id"] for stage in stages if stage["status"] == "pending"),
        "complete" if state.get("status") == "completed" else "blocked",
    )
    return {
        "execution_status": loop_state.get("status") if loop_state else "scheduled",
        "current_stage": current,
        "stages": stages,
    }


def _actor_projection(
    reader: CampaignReader,
    *,
    role: str,
    loop_id: str,
    role_result_path: Path | None,
    manifest: dict[str, object] | None,
    loop_state: dict[str, object] | None,
) -> dict[str, object]:
    result = (
        _optional_json(role_result_path, ROLE_RESULT_SCHEMA)
        if role_result_path is not None
        else None
    )
    manifest_role = manifest.get(f"{role}_adapter") if manifest else None
    manifest_role = manifest_role if isinstance(manifest_role, dict) else {}
    active = (
        loop_state is not None
        and loop_state.get("operation") == f"{role}_turn"
        and loop_state.get("operation_status") == "running"
    )
    adapter_id = (
        result.get("adapter_id") if result else manifest_role.get("id", "unavailable")
    )
    session_id = result.get("session_id") if result else None
    native_ref = _loop_relative_role_ref(reader, loop_id, result, "native_store_ref")
    events_ref = _loop_relative_role_ref(reader, loop_id, result, "agent_events_ref")
    export_available = bool(adapter_id == "opencode" and session_id and native_ref)
    return {
        "role": role,
        "status": "running" if active else (result.get("status") if result else "pending"),
        "adapter_id": adapter_id,
        "model": manifest_role.get("model", "unavailable"),
        "reasoning_variant": manifest_role.get("reasoning_variant", "unavailable"),
        "session_id": session_id,
        "normalized_events_ref": events_ref,
        "native_store_ref": native_ref,
        "event_parse_status": result.get("event_parse_status") if result else "unavailable",
        "capabilities": {
            "resume": "unavailable",
            "snapshot": "unavailable",
            "fork": "unavailable",
            "export": "on_demand" if export_available else "unavailable",
            "replay": "not_claimed",
        },
        "limitation": (
            "Stored session ID and native store support post-analysis export only; "
            "resume and replay are not claimed."
            if export_available
            else "No negotiated session capability or replay guarantee is available."
        ),
    }


def _loop_relative_role_ref(
    reader: CampaignReader,
    loop_id: str,
    result: dict[str, object] | None,
    key: str,
) -> str | None:
    value = result.get(key) if result else None
    if not isinstance(value, str) or not _safe_relative_ref(value):
        return None
    path = reader.workspace / ".pact" / "loops" / loop_id / value
    return reader.relative_ref(path)


def _read_event_projection(path: Path) -> tuple[list[dict[str, object]], str]:
    if not path.is_file():
        return [], "pending"
    try:
        text = path.read_text(encoding="utf-8")
        if text and not text.endswith("\n"):
            return [], "corrupt"
        events: list[dict[str, object]] = []
        for index, line in enumerate(text.splitlines()):
            value = json.loads(line)
            if (
                not isinstance(value, dict)
                or value.get("schema") != EVENT_SCHEMA
                or value.get("seq") != index
            ):
                return [], "corrupt"
            events.append(value)
        return events, "ready"
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return [], "corrupt"


def _timeline_item(event: dict[str, object]) -> dict[str, object]:
    return {
        key: event[key]
        for key in ("seq", "ts", "event", "operation", "role", "round", "status")
        if key in event and isinstance(event[key], (str, int)) and not isinstance(event[key], bool)
    }


def _optional_json(path: Path, schema: str) -> dict[str, object] | None:
    if not path.is_file():
        return None
    try:
        payload = read_json(path)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError):
        return None
    return payload if payload.get("schema") == schema else None


def _without_generated_at(payload: dict[str, object]) -> dict[str, object]:
    return {key: value for key, value in payload.items() if key != "generated_at"}


def _resolve_workspace_ref(workspace: Path, ref: str) -> Path | None:
    if not _safe_relative_ref(ref):
        return None
    path = (workspace / PurePosixPath(ref)).resolve()
    try:
        path.relative_to(workspace.resolve())
    except ValueError:
        return None
    return path


def _safe_relative_ref(ref: str) -> bool:
    path = PurePosixPath(ref)
    return not path.is_absolute() and ".." not in path.parts


def _required_object(payload: dict[str, object], key: str) -> dict[str, object]:
    value = payload.get(key)
    if not isinstance(value, dict):
        return {}
    return value


def _required_str(payload: dict[str, object], key: str) -> str:
    value = payload.get(key)
    return value if isinstance(value, str) else "unavailable"


def _mission_projection(
    state: dict[str, object],
    plan_revision: dict[str, object],
) -> list[dict[str, object]]:
    state_missions = state.get("missions")
    definitions = plan_revision.get("missions")
    if not isinstance(state_missions, list) or not isinstance(definitions, list):
        return []
    state_by_id = {
        item.get("id"): item
        for item in state_missions
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    result: list[dict[str, object]] = []
    for definition in definitions:
        if not isinstance(definition, dict) or not isinstance(definition.get("id"), str):
            continue
        merged = {**definition, **state_by_id.get(definition["id"], {})}
        result.append(
            {
                "id": merged.get("id"),
                "status": merged.get("status"),
                "objective": _bounded_text(merged.get("objective"), limit=800),
                "target_ac_ids": _string_list(merged.get("target_ac_ids")),
                "dependencies": _string_list(merged.get("dependencies")),
                "successors": _string_list(merged.get("successors")),
                "supersedes": _string_list(merged.get("supersedes")),
                "execution_refs": [
                    ref for ref in _string_list(merged.get("execution_refs"))
                    if _safe_relative_ref(ref)
                ],
                "evidence_refs": [
                    ref for ref in _string_list(merged.get("evidence_refs"))
                    if _safe_relative_ref(ref)
                ],
            }
        )
    return result


def _string_list(value: object) -> list[str]:
    return [item for item in value if isinstance(item, str)] if isinstance(value, list) else []


def _safe_criteria(criteria: list[object]) -> list[dict[str, object]]:
    safe: list[dict[str, object]] = []
    for item in criteria:
        if not isinstance(item, dict):
            continue
        criterion_id = item.get("id")
        text = item.get("text")
        if not isinstance(criterion_id, str) or not isinstance(text, str):
            continue
        safe.append(
            {
                "id": criterion_id,
                "text": text,
                "status": item.get("status", "pending"),
                "evidence_refs": [
                    ref for ref in _string_list(item.get("evidence_refs"))
                    if _safe_relative_ref(ref)
                ],
            }
        )
    return safe


def _non_negative_int(value: object) -> int:
    return value if isinstance(value, int) and not isinstance(value, bool) and value >= 0 else 0


__all__ = [
    "DASHBOARD_PROJECTION_SCHEMA",
    "build_dashboard_projection",
    "empty_dashboard_projection",
    "write_dashboard_projection",
]
