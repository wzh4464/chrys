"""Planner proposal contract and thin AgentAdapter-backed provider."""

from __future__ import annotations

import hashlib
import json
import tempfile
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Protocol, runtime_checkable

from pact_core.adapters.base import AgentAdapter
from pact_core.prompts import (
    build_planner_prompt,
    build_semantic_json_repair_prompt,
    planner_operation_contract,
)
from pact_core.runtime.planning import InitialPlan, MissionDefinition, validate_initial_plan
from pact_core.runtime.schemas import (
    INITIAL_PLAN_SCHEMA,
    PLAN_REVISION_PROPOSAL_SCHEMA,
    RuntimeContractError,
    RuntimeRepairableOutputError,
)
from pact_core.schemas import TurnRequest


@dataclass(frozen=True, slots=True)
class PlanningRequest:
    campaign_id: str
    contract_revision: int
    plan_revision: int
    work_state_revision: int
    trigger: str
    manager_constraints: tuple[str, ...]
    acceptance_criterion_ids: tuple[str, ...]
    parent_plan: InitialPlan
    projection: dict[str, object]
    artifact_dir: Path | None = None


@dataclass(frozen=True, slots=True)
class PlanRevisionProposal:
    parent_plan_revision: int
    input_work_state_revision: int
    reason: str
    rationale: str
    plan: InitialPlan
    operations: tuple[dict[str, object], ...]
    affected_mission_ids: tuple[str, ...]
    affected_ac_ids: tuple[str, ...]
    repair_attempted: bool = False

    @property
    def sha256(self) -> str:
        encoded = json.dumps(
            proposal_payload(self),
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()


@runtime_checkable
class PlanningProvider(Protocol):
    def propose(self, request: PlanningRequest) -> PlanRevisionProposal:
        """Return one revision-bound Plan proposal without mutating canonical state."""
        ...


class FakePlanningProvider:
    """Deterministic proposal script for hermetic Runtime tests."""

    def __init__(self, proposals: list[PlanRevisionProposal]) -> None:
        self._proposals = list(proposals)
        self._next = 0
        self.requests: list[PlanningRequest] = []

    def propose(self, request: PlanningRequest) -> PlanRevisionProposal:
        self.requests.append(request)
        if self._next >= len(self._proposals):
            raise AssertionError("FakePlanningProvider script exhausted")
        proposal = self._proposals[self._next]
        self._next += 1
        return proposal


class AdapterPlanningProvider:
    """Run Planner turns through an existing AgentAdapter process boundary."""

    def __init__(self, adapter: AgentAdapter, *, timeout_seconds: float = 3600.0) -> None:
        self._adapter = adapter
        self._timeout_seconds = timeout_seconds
        self._probed = False

    def propose(self, request: PlanningRequest) -> PlanRevisionProposal:
        prompt = build_planner_prompt(
            projection=request.projection,
            proposal_schema=PLAN_REVISION_PROPOSAL_SCHEMA,
        )
        first = self._run(prompt, request.artifact_dir, "initial")
        try:
            return parse_plan_revision_proposal(first, request=request)
        except RuntimeRepairableOutputError as initial_error:
            semantic_fingerprint = _planner_repair_fingerprint(first)
            if semantic_fingerprint is None:
                raise initial_error
            repair = self._run(
                build_semantic_json_repair_prompt(
                    role="Planner",
                    invalid_output=first,
                    error=str(initial_error),
                    contract=planner_output_contract(),
                ),
                request.artifact_dir,
                "repair",
            )
            try:
                proposal = parse_plan_revision_proposal(repair, request=request)
            except RuntimeContractError as repair_error:
                raise RuntimeContractError(
                    f"Planner proposal remained invalid after one format repair: "
                    f"{repair_error}"
                ) from repair_error
            repaired_fingerprint = _planner_repair_fingerprint(
                json.dumps(proposal_payload(proposal))
            )
            if repaired_fingerprint != semantic_fingerprint:
                raise RuntimeContractError(
                    "format repair changed Planner semantics"
                )
            return replace(proposal, repair_attempted=True)

    def _run(self, prompt: str, artifact_dir: Path | None, attempt: str) -> str:
        if not self._probed:
            probe = self._adapter.probe()
            if not probe.available:
                raise RuntimeContractError(
                    f"Planner adapter is unavailable: {probe.detail or probe.version}"
                )
            self._probed = True
        with tempfile.TemporaryDirectory(prefix="pact-planner-") as raw_workdir:
            turn_artifacts = artifact_dir / attempt if artifact_dir is not None else None
            result = self._adapter.run_turn(
                TurnRequest(
                    role="worker",
                    prompt=prompt,
                    workdir=Path(raw_workdir),
                    timeout_seconds=self._timeout_seconds,
                    artifact_dir=turn_artifacts,
                )
            )
        if result.status != "completed" or not result.final_text.strip():
            raise RuntimeContractError(
                f"Planner provider turn was unusable: {result.status}"
            )
        return result.final_text


def planner_output_contract() -> str:
    return (
        "exactly one JSON object with schema, parent_plan_revision, "
        "input_work_state_revision, reason, rationale, constraints, missions, "
        "operations, affected_mission_ids, and affected_ac_ids. "
        + planner_operation_contract()
    )


def parse_plan_revision_proposal(
    raw_text: str,
    *,
    request: PlanningRequest,
) -> PlanRevisionProposal:
    payload = _json_object(raw_text, "Planner proposal")
    expected_fields = {
        "schema",
        "parent_plan_revision",
        "input_work_state_revision",
        "reason",
        "rationale",
        "constraints",
        "missions",
        "operations",
        "affected_mission_ids",
        "affected_ac_ids",
    }
    if set(payload) != expected_fields:
        raise RuntimeRepairableOutputError(
            "Planner proposal must contain exactly the current proposal fields"
        )
    if payload.get("schema") != PLAN_REVISION_PROPOSAL_SCHEMA:
        raise RuntimeRepairableOutputError("unsupported Planner proposal schema")
    parent_revision = _required_int(payload, "parent_plan_revision")
    work_state_revision = _required_int(payload, "input_work_state_revision")
    if parent_revision != request.plan_revision:
        raise RuntimeContractError("Planner proposal parent Plan revision is stale")
    if work_state_revision != request.work_state_revision:
        raise RuntimeContractError("Planner proposal input Work State revision is stale")
    reason = _required_text(payload, "reason")
    rationale = _bounded_text(payload, "rationale")
    constraints = _string_tuple(payload.get("constraints"), "constraints")
    if constraints != request.parent_plan.constraints:
        raise RuntimeContractError("R3 Planner cannot change Plan constraints")
    raw_missions = payload.get("missions")
    if not isinstance(raw_missions, list):
        raise RuntimeRepairableOutputError("Planner proposal missions must be an array")
    stripped_missions: list[dict[str, object]] = []
    supersedes_by_id: dict[str, tuple[str, ...]] = {}
    for index, value in enumerate(raw_missions):
        if not isinstance(value, dict):
            raise RuntimeRepairableOutputError(
                f"Planner missions[{index}] must be an object"
            )
        allowed = {
            "id",
            "objective",
            "target_ac_ids",
            "dependencies",
            "supersedes",
            "verification_intent",
        }
        if set(value) != allowed:
            raise RuntimeRepairableOutputError(
                f"Planner missions[{index}] must contain exactly the Mission fields"
            )
        mission_id = value.get("id")
        if not isinstance(mission_id, str):
            raise RuntimeRepairableOutputError(
                f"Planner missions[{index}].id must be a string"
            )
        supersedes_by_id[mission_id] = _string_tuple(
            value.get("supersedes"), f"missions[{index}].supersedes"
        )
        stripped_missions.append(
            {key: item for key, item in value.items() if key != "supersedes"}
        )
    base_plan = validate_initial_plan(
        {
            "schema": INITIAL_PLAN_SCHEMA,
            "constraints": list(constraints),
            "missions": stripped_missions,
        },
        acceptance_criterion_ids=request.acceptance_criterion_ids,
    )
    plan = InitialPlan(
        missions=tuple(
            replace(mission, supersedes=supersedes_by_id[mission.id])
            for mission in base_plan.missions
        ),
        constraints=base_plan.constraints,
    )
    operations = _validate_material_delta(
        payload.get("operations"),
        parent=request.parent_plan,
        proposal=plan,
        acceptance_criterion_ids=request.acceptance_criterion_ids,
    )
    affected_mission_ids = _string_tuple(
        payload.get("affected_mission_ids"), "affected_mission_ids"
    )
    affected_ac_ids = _string_tuple(payload.get("affected_ac_ids"), "affected_ac_ids")
    _validate_affected_sets(
        parent=request.parent_plan,
        proposal=plan,
        operations=operations,
        affected_mission_ids=affected_mission_ids,
        affected_ac_ids=affected_ac_ids,
    )
    return PlanRevisionProposal(
        parent_plan_revision=parent_revision,
        input_work_state_revision=work_state_revision,
        reason=reason,
        rationale=rationale,
        plan=plan,
        operations=operations,
        affected_mission_ids=affected_mission_ids,
        affected_ac_ids=affected_ac_ids,
    )


def proposal_payload(proposal: PlanRevisionProposal) -> dict[str, object]:
    return {
        "schema": PLAN_REVISION_PROPOSAL_SCHEMA,
        "parent_plan_revision": proposal.parent_plan_revision,
        "input_work_state_revision": proposal.input_work_state_revision,
        "reason": proposal.reason,
        "rationale": proposal.rationale,
        "constraints": list(proposal.plan.constraints),
        "missions": [
            {
                "id": mission.id,
                "objective": mission.objective,
                "target_ac_ids": list(mission.target_ac_ids),
                "dependencies": list(mission.dependencies),
                "supersedes": list(mission.supersedes),
                "verification_intent": mission.verification_intent,
            }
            for mission in proposal.plan.missions
        ],
        "operations": [dict(operation) for operation in proposal.operations],
        "affected_mission_ids": list(proposal.affected_mission_ids),
        "affected_ac_ids": list(proposal.affected_ac_ids),
    }


def validate_plan_revision_proposal(
    proposal: PlanRevisionProposal,
    *,
    request: PlanningRequest,
) -> PlanRevisionProposal:
    """Apply the same strict checks to programmatic/Fake provider output."""
    normalized = parse_plan_revision_proposal(
        json.dumps(proposal_payload(proposal)),
        request=request,
    )
    return replace(normalized, repair_attempted=proposal.repair_attempted)


def _validate_material_delta(
    raw_operations: object,
    *,
    parent: InitialPlan,
    proposal: InitialPlan,
    acceptance_criterion_ids: tuple[str, ...],
) -> tuple[dict[str, object], ...]:
    if not isinstance(raw_operations, list) or not raw_operations:
        raise RuntimeContractError("Planner proposal requires a non-empty material delta")
    parent_by_id = {mission.id: mission for mission in parent.missions}
    proposal_by_id = {mission.id: mission for mission in proposal.missions}
    if not set(parent_by_id).issubset(proposal_by_id):
        raise RuntimeContractError("Planner proposal cannot delete existing Missions")
    for mission_id, old in parent_by_id.items():
        new = proposal_by_id[mission_id]
        if _stable_definition(old) != _stable_definition(new):
            raise RuntimeContractError(
                f"Planner proposal cannot mutate existing Mission: {mission_id}"
            )
    new_ids = set(proposal_by_id).difference(parent_by_id)
    superseded_ids: set[str] = set()
    added_by_operation: set[str] = set()
    replacement_map: dict[str, set[str]] = {}
    normalized: list[dict[str, object]] = []
    for index, value in enumerate(raw_operations):
        if not isinstance(value, dict):
            raise RuntimeRepairableOutputError(
                f"operations[{index}] must be an object"
            )
        op = value.get("op")
        if op == "add_mission" and set(value) == {"op", "mission_id"}:
            operation_mission_id = value.get("mission_id")
            if (
                not isinstance(operation_mission_id, str)
                or operation_mission_id not in new_ids
            ):
                raise RuntimeContractError("add_mission must reference a new Mission")
            if operation_mission_id in added_by_operation:
                raise RuntimeContractError("Plan operations contain duplicate add_mission")
            added_by_operation.add(operation_mission_id)
            normalized.append({"op": op, "mission_id": operation_mission_id})
            continue
        if op == "supersede_mission" and set(value) == {
            "op",
            "mission_id",
            "replacement_mission_ids",
        }:
            operation_mission_id = value.get("mission_id")
            replacements = _string_tuple(
                value.get("replacement_mission_ids"),
                f"operations[{index}].replacement_mission_ids",
            )
            if (
                not isinstance(operation_mission_id, str)
                or operation_mission_id not in parent_by_id
                or not replacements
                or any(item not in new_ids for item in replacements)
            ):
                raise RuntimeContractError(
                    "supersede_mission must bind an old Mission to new replacements"
                )
            if any(
                operation_mission_id not in proposal_by_id[item].supersedes
                for item in replacements
            ):
                raise RuntimeRepairableOutputError(
                    "replacement supersedes refs do not match operation"
                )
            if operation_mission_id in superseded_ids:
                raise RuntimeContractError(
                    "Plan operations contain duplicate supersede_mission"
                )
            superseded_ids.add(operation_mission_id)
            replacement_map[operation_mission_id] = set(replacements)
            normalized.append(
                {
                    "op": op,
                    "mission_id": operation_mission_id,
                    "replacement_mission_ids": list(replacements),
                }
            )
            continue
        raise RuntimeRepairableOutputError(
            f"unsupported or malformed Plan operation at index {index}; expected "
            "exactly {op, mission_id} for add_mission or "
            "{op, mission_id, replacement_mission_ids} for supersede_mission; "
            f"received fields {sorted(value)}"
        )
    if added_by_operation != new_ids:
        raise RuntimeContractError("Plan operations must account for every new Mission")
    declared_replacements: dict[str, set[str]] = {}
    for mission in proposal.missions:
        for old_id in mission.supersedes:
            declared_replacements.setdefault(old_id, set()).add(mission.id)
    declared_supersedes = set(declared_replacements)
    if declared_supersedes != superseded_ids:
        raise RuntimeRepairableOutputError(
            "Plan operations must account for every superseded Mission"
        )
    if declared_replacements != replacement_map:
        raise RuntimeRepairableOutputError(
            "supersede_mission replacement ids must exactly match Mission refs"
        )
    if any(old_id not in parent_by_id for old_id in declared_supersedes):
        raise RuntimeContractError("new Mission supersedes an unknown parent Mission")
    active = [mission for mission in proposal.missions if mission.id not in superseded_ids]
    covered = {ac_id for mission in active for ac_id in mission.target_ac_ids}
    if covered != set(acceptance_criterion_ids):
        raise RuntimeContractError("active proposed Missions must cover every current AC")
    return tuple(normalized)


def _validate_affected_sets(
    *,
    parent: InitialPlan,
    proposal: InitialPlan,
    operations: tuple[dict[str, object], ...],
    affected_mission_ids: tuple[str, ...],
    affected_ac_ids: tuple[str, ...],
) -> None:
    if len(set(affected_mission_ids)) != len(affected_mission_ids):
        raise RuntimeContractError("affected_mission_ids contains duplicates")
    if len(set(affected_ac_ids)) != len(affected_ac_ids):
        raise RuntimeContractError("affected_ac_ids contains duplicates")
    material_ids: set[str] = set()
    for operation in operations:
        mission_id = operation["mission_id"]
        assert isinstance(mission_id, str)
        material_ids.add(mission_id)
        replacements = operation.get("replacement_mission_ids")
        if isinstance(replacements, list):
            material_ids.update(item for item in replacements if isinstance(item, str))
    if set(affected_mission_ids) != material_ids:
        raise RuntimeContractError("affected_mission_ids do not match material operations")
    by_id = {mission.id: mission for mission in (*parent.missions, *proposal.missions)}
    material_ac_ids = {
        ac_id for mission_id in material_ids for ac_id in by_id[mission_id].target_ac_ids
    }
    if set(affected_ac_ids) != material_ac_ids:
        raise RuntimeContractError("affected_ac_ids do not match affected Missions")


def _stable_definition(mission: MissionDefinition) -> tuple[object, ...]:
    return (
        mission.id,
        mission.objective,
        mission.target_ac_ids,
        mission.dependencies,
        mission.supersedes,
        mission.verification_intent,
    )


def _json_object(raw_text: str, label: str) -> dict[str, object]:
    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise RuntimeRepairableOutputError(
            f"{label} is not valid JSON: {exc.msg}"
        ) from exc
    if not isinstance(payload, dict):
        raise RuntimeRepairableOutputError(f"{label} must be a JSON object")
    return payload


def _planner_repair_fingerprint(raw_text: str) -> str | None:
    """Capture the proposed route while excluding only operation transport."""
    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    semantic_fields = {
        "parent_plan_revision",
        "input_work_state_revision",
        "reason",
        "rationale",
        "constraints",
        "missions",
        "affected_mission_ids",
        "affected_ac_ids",
    }
    if not semantic_fields.issubset(payload):
        return None
    semantic = {key: payload[key] for key in semantic_fields}
    return json.dumps(semantic, sort_keys=True, ensure_ascii=False)


def _required_int(payload: dict[str, object], key: str) -> int:
    value = payload.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise RuntimeContractError(f"{key} must be a non-negative integer")
    return value


def _required_text(payload: dict[str, object], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value.strip():
        raise RuntimeContractError(f"{key} must be a non-empty string")
    return value.strip()


def _bounded_text(payload: dict[str, object], key: str) -> str:
    value = _required_text(payload, key)
    if len(value) > 8_000:
        raise RuntimeContractError(f"{key} exceeds the bounded Runtime limit")
    return value


def _string_tuple(value: object, label: str) -> tuple[str, ...]:
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item.strip() for item in value
    ):
        raise RuntimeContractError(f"{label} must be an array of non-empty strings")
    result = tuple(item.strip() for item in value)
    if len(set(result)) != len(result):
        raise RuntimeContractError(f"{label} contains duplicates")
    return result


__all__ = [
    "AdapterPlanningProvider",
    "FakePlanningProvider",
    "PlanRevisionProposal",
    "PlanningProvider",
    "PlanningRequest",
    "parse_plan_revision_proposal",
    "proposal_payload",
    "validate_plan_revision_proposal",
]
