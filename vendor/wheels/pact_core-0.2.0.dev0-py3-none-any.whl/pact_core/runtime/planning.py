"""Pure Initial Plan validation and deterministic Frontier calculation."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

from pact_core.runtime.schemas import (
    INITIAL_PLAN_SCHEMA,
    CampaignStatus,
    RuntimeContractError,
)

_ID_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*\Z")

MissionStatus = Literal[
    "pending",
    "active",
    "blocked",
    "completed",
    "superseded",
    "abandoned",
]


@dataclass(frozen=True, slots=True)
class MissionDefinition:
    id: str
    objective: str
    target_ac_ids: tuple[str, ...]
    dependencies: tuple[str, ...]
    successors: tuple[str, ...]
    supersedes: tuple[str, ...]
    verification_intent: str


@dataclass(frozen=True, slots=True)
class InitialPlan:
    missions: tuple[MissionDefinition, ...]
    constraints: tuple[str, ...]

    def mission(self, mission_id: str) -> MissionDefinition:
        for mission in self.missions:
            if mission.id == mission_id:
                return mission
        raise RuntimeContractError(f"unknown Mission id: {mission_id}")


def initial_plan_payload(plan: InitialPlan) -> dict[str, object]:
    """Return the normalized user-authored Initial Plan shape."""
    return {
        "schema": INITIAL_PLAN_SCHEMA,
        "constraints": list(plan.constraints),
        "missions": [
            {
                "id": mission.id,
                "objective": mission.objective,
                "target_ac_ids": list(mission.target_ac_ids),
                "dependencies": list(mission.dependencies),
                "verification_intent": mission.verification_intent,
            }
            for mission in plan.missions
        ],
    }


def plan_revision_missions(
    plan: InitialPlan,
    *,
    plan_refs: dict[str, str],
) -> list[dict[str, object]]:
    """Build immutable canonical Mission definitions for PlanRevision 1."""
    expected_ids = {mission.id for mission in plan.missions}
    if set(plan_refs) != expected_ids:
        raise RuntimeContractError("Mission plan refs do not match the Initial Plan")
    return [
        {
            "id": mission.id,
            "objective": mission.objective,
            "target_ac_ids": list(mission.target_ac_ids),
            "dependencies": list(mission.dependencies),
            "successors": list(mission.successors),
            "supersedes": list(mission.supersedes),
            "verification_intent": mission.verification_intent,
            "plan_ref": plan_refs[mission.id],
        }
        for mission in plan.missions
    ]


def validate_initial_plan(
    payload: dict[str, object],
    *,
    acceptance_criterion_ids: tuple[str, ...],
) -> InitialPlan:
    """Validate a user-accepted Initial Plan and derive successor refs."""
    if payload.get("schema") != INITIAL_PLAN_SCHEMA:
        raise RuntimeContractError(
            f"unsupported Initial Plan schema: {payload.get('schema')!r}"
        )
    allowed_top_level = {"schema", "missions", "constraints"}
    unknown_top_level = set(payload).difference(allowed_top_level)
    if unknown_top_level:
        raise RuntimeContractError(
            f"Initial Plan contains unsupported field(s): {sorted(unknown_top_level)}"
        )
    raw_constraints = payload.get("constraints", [])
    constraints = _string_array(raw_constraints, "Initial Plan constraints")
    raw_missions = payload.get("missions")
    if not isinstance(raw_missions, list) or not raw_missions:
        raise RuntimeContractError("Initial Plan missions must be a non-empty array")

    ac_ids = set(acceptance_criterion_ids)
    if len(ac_ids) != len(acceptance_criterion_ids):
        raise RuntimeContractError("Goal Contract acceptance criterion ids must be unique")
    staged: list[tuple[str, str, tuple[str, ...], tuple[str, ...], str]] = []
    seen_ids: set[str] = set()
    targeted_ac_ids: set[str] = set()
    allowed_mission_fields = {
        "id",
        "objective",
        "target_ac_ids",
        "dependencies",
        "verification_intent",
    }
    for index, raw_mission in enumerate(raw_missions):
        label = f"Initial Plan missions[{index}]"
        if not isinstance(raw_mission, dict):
            raise RuntimeContractError(f"{label} must be an object")
        unknown_fields = set(raw_mission).difference(allowed_mission_fields)
        if unknown_fields:
            raise RuntimeContractError(
                f"{label} contains unsupported field(s): {sorted(unknown_fields)}"
            )
        mission_id = _non_empty_string(raw_mission.get("id"), f"{label}.id")
        if not _ID_RE.fullmatch(mission_id):
            raise RuntimeContractError(f"{label}.id is not a stable identifier")
        if mission_id in seen_ids:
            raise RuntimeContractError(f"duplicate Mission id: {mission_id}")
        seen_ids.add(mission_id)
        objective = _non_empty_string(
            raw_mission.get("objective"), f"{label}.objective"
        )
        target_ac_ids = _string_array(
            raw_mission.get("target_ac_ids"), f"{label}.target_ac_ids"
        )
        if not target_ac_ids:
            raise RuntimeContractError(f"{label}.target_ac_ids must not be empty")
        if len(set(target_ac_ids)) != len(target_ac_ids):
            raise RuntimeContractError(f"{label}.target_ac_ids contains duplicates")
        unknown_ac_ids = set(target_ac_ids).difference(ac_ids)
        if unknown_ac_ids:
            raise RuntimeContractError(
                f"{label} references unknown AC id(s): {sorted(unknown_ac_ids)}"
            )
        targeted_ac_ids.update(target_ac_ids)
        dependencies = _string_array(
            raw_mission.get("dependencies"), f"{label}.dependencies"
        )
        if len(set(dependencies)) != len(dependencies):
            raise RuntimeContractError(f"{label}.dependencies contains duplicates")
        verification_intent = _non_empty_string(
            raw_mission.get("verification_intent"),
            f"{label}.verification_intent",
        )
        staged.append(
            (
                mission_id,
                objective,
                target_ac_ids,
                dependencies,
                verification_intent,
            )
        )

    missing_ac_ids = ac_ids.difference(targeted_ac_ids)
    if missing_ac_ids:
        raise RuntimeContractError(
            f"Initial Plan does not target AC id(s): {sorted(missing_ac_ids)}"
        )
    dependencies_by_id = {item[0]: item[3] for item in staged}
    for mission_id, dependencies in dependencies_by_id.items():
        missing_dependencies = set(dependencies).difference(seen_ids)
        if missing_dependencies:
            raise RuntimeContractError(
                f"Mission {mission_id} references unknown dependency id(s): "
                f"{sorted(missing_dependencies)}"
            )
        if mission_id in dependencies:
            raise RuntimeContractError(f"Mission {mission_id} cannot depend on itself")
    _assert_acyclic(dependencies_by_id)

    successors: dict[str, list[str]] = {mission_id: [] for mission_id in seen_ids}
    for mission_id, dependencies in dependencies_by_id.items():
        for dependency in dependencies:
            successors[dependency].append(mission_id)
    missions = tuple(
        MissionDefinition(
            id=mission_id,
            objective=objective,
            target_ac_ids=target_ac_ids,
            dependencies=dependencies,
            successors=tuple(sorted(successors[mission_id])),
            supersedes=(),
            verification_intent=verification_intent,
        )
        for (
            mission_id,
            objective,
            target_ac_ids,
            dependencies,
            verification_intent,
        ) in staged
    )
    return InitialPlan(missions=missions, constraints=constraints)


def compute_frontier(
    plan: InitialPlan,
    mission_statuses: dict[str, MissionStatus],
) -> tuple[str, ...]:
    """Return eligible Mission ids in stable Plan order."""
    plan_ids = {mission.id for mission in plan.missions}
    if set(mission_statuses) != plan_ids:
        missing = plan_ids.difference(mission_statuses)
        unknown = set(mission_statuses).difference(plan_ids)
        raise RuntimeContractError(
            f"Mission status map mismatch; missing={sorted(missing)}, "
            f"unknown={sorted(unknown)}"
        )
    completed = {
        mission_id
        for mission_id, status in mission_statuses.items()
        if status == "completed"
    }
    return tuple(
        mission.id
        for mission in plan.missions
        if mission_statuses[mission.id] == "pending"
        and set(mission.dependencies).issubset(completed)
    )


def classify_frontier(
    frontier: tuple[str, ...],
) -> tuple[CampaignStatus, str, str]:
    """Map a deterministic Frontier to the next governed Runtime action."""
    if len(frontier) == 1:
        return "active", "execute_mission", "single_eligible_mission"
    if frontier:
        return "blocked", "manager_select_frontier", "manager_selection_required"
    return "blocked", "manager_resolve_empty_frontier", "frontier_empty"


def scheduled_execution(
    campaign_id: str,
    mission_id: str | None,
    *,
    plan_revision: int = 1,
    attempt: int = 1,
) -> dict[str, object]:
    """Build the Work State execution slot for one selected Mission."""
    return {
        "mission_id": mission_id,
        "loop_id": (
            f"{campaign_id}-{mission_id}-plan-{plan_revision}-attempt-{attempt}"
            if mission_id is not None
            else None
        ),
        "status": "scheduled" if mission_id is not None else "not_scheduled",
        "attempt": attempt if mission_id is not None else None,
        "outcome_ref": None,
        "candidate_checkpoint": None,
        "promotion_ref": None,
    }


def _assert_acyclic(dependencies_by_id: dict[str, tuple[str, ...]]) -> None:
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(mission_id: str) -> None:
        if mission_id in visiting:
            raise RuntimeContractError("Initial Plan Mission dependencies contain a cycle")
        if mission_id in visited:
            return
        visiting.add(mission_id)
        for dependency in dependencies_by_id[mission_id]:
            visit(dependency)
        visiting.remove(mission_id)
        visited.add(mission_id)

    for mission_id in dependencies_by_id:
        visit(mission_id)


def _non_empty_string(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise RuntimeContractError(f"{label} must be a non-empty string")
    return value.strip()


def _string_array(value: object, label: str) -> tuple[str, ...]:
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item.strip() for item in value
    ):
        raise RuntimeContractError(f"{label} must be an array of non-empty strings")
    return tuple(item.strip() for item in value)
