"""CLI entry point: `pact run` (PRD FR-1)."""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from pathlib import Path

from pact_core import __version__
from pact_core.adapters import SUPPORTED_ADAPTERS, UnknownAdapterError, create_adapter
from pact_core.artifacts import EventLogCorruptionError
from pact_core.checkpoint import PactGitError
from pact_core.config import LoopConfig
from pact_core.controller import PactLoopError, run_loop
from pact_core.kernel import KernelContractError
from pact_core.runtime import (
    AdapterDecisionProvider,
    AdapterPlanningProvider,
    CampaignControlPlane,
    CampaignRunRequest,
    RuntimeContractError,
    RuntimeStateError,
)
from pact_core.runtime.dashboard import serve_dashboard


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pact",
        description=(
            "Run plan-anchored checkpointed task loops (PACT) "
            "against any coding agent CLI."
        ),
    )
    parser.add_argument("--version", action="version", version=f"pact-core {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    run = subparsers.add_parser("run", help="run one PACT loop to a terminal state")
    _add_execution_arguments(run)

    campaign = subparsers.add_parser(
        "campaign", help="run or inspect work-centric Campaigns"
    )
    campaign_commands = campaign.add_subparsers(dest="campaign_command")
    campaign_run = campaign_commands.add_parser(
        "run", help="run the sequential multi-Mission Runtime demo"
    )
    campaign_run.add_argument(
        "--contract", required=True, type=Path, help="path to Goal Contract JSON"
    )
    campaign_run.add_argument("--campaign-id", default=None)
    campaign_run.add_argument(
        "--planner-adapter",
        default=None,
        help=(
            "optional semantic Planner adapter for governed replan "
            f"({', '.join(SUPPORTED_ADAPTERS)})"
        ),
    )
    campaign_run.add_argument(
        "--manager-adapter",
        default=None,
        help=(
            "optional semantic Manager adapter for routing/approval "
            f"({', '.join(SUPPORTED_ADAPTERS)})"
        ),
    )
    _add_execution_arguments(
        campaign_run,
        include_loop_id=False,
        plan_help="path to the user-accepted structured Initial Plan JSON",
    )
    campaign_dashboard = campaign_commands.add_parser(
        "dashboard", help="serve the read-only Campaign Dashboard on loopback"
    )
    campaign_dashboard.add_argument("--campaign", default="latest")
    campaign_dashboard.add_argument(
        "--workspace", type=Path, default=Path.cwd(), help="source repository root"
    )
    campaign_dashboard.add_argument("--port", type=int, default=8765)
    return parser


def _add_execution_arguments(
    command: argparse.ArgumentParser,
    *,
    include_loop_id: bool = True,
    plan_help: str = "path to the accepted plan file",
) -> None:
    command.add_argument(
        "--plan", required=True, type=Path, help=plan_help
    )
    command.add_argument(
        "--worker-adapter",
        required=True,
        help=f"worker agent adapter ({', '.join(SUPPORTED_ADAPTERS)})",
    )
    command.add_argument(
        "--reviewer-adapter",
        required=True,
        help=f"reviewer agent adapter ({', '.join(SUPPORTED_ADAPTERS)})",
    )
    command.add_argument(
        "--verify",
        default=None,
        metavar="CMD",
        help=(
            "agent-visible per-round verification command; never use for "
            "private or hidden tests (exit 0 = passed)"
        ),
    )
    command.add_argument(
        "--final-verify",
        default=None,
        metavar="CMD",
        help="opaque terminal validation command run once after gate convergence",
    )
    command.add_argument("--max-rounds", type=int, default=3)
    command.add_argument(
        "--allow-unverified",
        action="store_true",
        help="permit completion when no verification command is configured (audited waiver)",
    )
    command.add_argument(
        "--workspace",
        type=Path,
        default=Path.cwd(),
        help="source repository root (default: current directory)",
    )
    if include_loop_id:
        command.add_argument("--loop-id", default=None)
    command.add_argument("--worktree-root", type=Path, default=None)
    command.add_argument(
        "--verify-timeout", type=float, default=1800.0, metavar="SECONDS"
    )
    command.add_argument(
        "--final-verify-timeout", type=float, default=1800.0, metavar="SECONDS"
    )
    command.add_argument("--turn-timeout", type=float, default=3600.0, metavar="SECONDS")


def _run_command(args: argparse.Namespace) -> int:
    config = LoopConfig(
        workspace=args.workspace,
        plan_file=args.plan,
        max_rounds=args.max_rounds,
        verify_command=args.verify,
        verify_timeout_seconds=args.verify_timeout,
        allow_unverified=args.allow_unverified,
        final_verify_command=args.final_verify,
        final_verify_timeout_seconds=args.final_verify_timeout,
        turn_timeout_seconds=args.turn_timeout,
        loop_id=args.loop_id,
        worktree_root=args.worktree_root,
    )
    worker = create_adapter(args.worker_adapter, role="worker", max_rounds=args.max_rounds)
    reviewer = create_adapter(args.reviewer_adapter, role="reviewer", max_rounds=args.max_rounds)
    summary = run_loop(config, worker=worker, reviewer=reviewer)

    print(f"loop:      {summary.loop_id}")
    print(f"status:    {summary.status} ({summary.stop_reason})")
    print(f"rounds:    {summary.rounds}")
    print(f"round gate: {summary.round_gate_status or 'not_reached'}")
    print(f"final:     {summary.final_validation_status or 'not_run'}")
    print(f"promotion: {summary.promotion_status}"
          + (f" ({summary.promotion_reason})" if summary.promotion_reason else ""))
    print(f"artifacts: {summary.loop_dir}")
    if summary.status == "complete" and summary.promotion_status in {"applied", "no_changes"}:
        return 0
    return 1


def _campaign_run_command(args: argparse.Namespace) -> int:
    worker = create_adapter(args.worker_adapter, role="worker", max_rounds=args.max_rounds)
    reviewer = create_adapter(args.reviewer_adapter, role="reviewer", max_rounds=args.max_rounds)
    planning_provider = (
        AdapterPlanningProvider(
            create_adapter(
                args.planner_adapter,
                role="worker",
                max_rounds=args.max_rounds * 2 + 2,
            ),
            timeout_seconds=args.turn_timeout,
        )
        if args.planner_adapter is not None
        else None
    )
    decision_provider = (
        AdapterDecisionProvider(
            create_adapter(
                args.manager_adapter,
                role="worker",
                max_rounds=args.max_rounds * 2 + 2,
            ),
            timeout_seconds=args.turn_timeout,
        )
        if args.manager_adapter is not None
        else None
    )
    result = CampaignControlPlane().run(
        CampaignRunRequest(
            workspace=args.workspace,
            contract_file=args.contract,
            plan_file=args.plan,
            worker=worker,
            reviewer=reviewer,
            verify_command=args.verify,
            max_rounds=args.max_rounds,
            verify_timeout_seconds=args.verify_timeout,
            allow_unverified=args.allow_unverified,
            final_verify_command=args.final_verify,
            final_verify_timeout_seconds=args.final_verify_timeout,
            turn_timeout_seconds=args.turn_timeout,
            campaign_id=args.campaign_id,
            worktree_root=args.worktree_root,
            planning_provider=planning_provider,
            decision_provider=decision_provider,
        )
    )
    print(f"campaign:  {result.campaign_id}")
    print(f"status:    {result.status}")
    print(f"revision:  {result.revision}")
    print(
        "executions: "
        + (
            ", ".join(outcome.loop_id for outcome in result.execution_outcomes)
            if result.execution_outcomes
            else "none"
        )
    )
    print(
        "promotion: "
        + (
            ", ".join(receipt.status for receipt in result.promotion_receipts)
            if result.promotion_receipts
            else "not_attempted"
        )
    )
    print(
        "evidence:  "
        + (", ".join(result.evidence_refs) if result.evidence_refs else "none")
    )
    print(f"artifacts: {result.campaign_dir}")
    return 0 if result.status == "completed" else 1


def _campaign_dashboard_command(args: argparse.Namespace) -> int:
    serve_dashboard(
        args.workspace,
        campaign=args.campaign,
        port=args.port,
    )
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command is None:
        parser.print_help()
        return 0
    if args.command == "run":
        try:
            return _run_command(args)
        except (
            EventLogCorruptionError,
            PactGitError,
            PactLoopError,
            UnknownAdapterError,
        ) as exc:
            print(f"pact: error: {exc}", file=sys.stderr)
            return 2
    if args.command == "campaign":
        if args.campaign_command is None:
            parser.parse_args(["campaign", "--help"])
            raise AssertionError("campaign help should exit")
        if args.campaign_command == "run":
            try:
                return _campaign_run_command(args)
            except (
                EventLogCorruptionError,
                KernelContractError,
                PactGitError,
                PactLoopError,
                RuntimeContractError,
                RuntimeStateError,
                UnknownAdapterError,
            ) as exc:
                print(f"pact: error: {exc}", file=sys.stderr)
                return 2
        if args.campaign_command == "dashboard":
            try:
                return _campaign_dashboard_command(args)
            except (OSError, ValueError) as exc:
                print(f"pact: error: {exc}", file=sys.stderr)
                return 2
    raise AssertionError(f"unhandled command: {args.command}")


if __name__ == "__main__":
    raise SystemExit(main())
