"""Deterministic verification of one checkpoint (never an agent turn).

Two layers (PRD FR-4): built-in structural checks that always run, plus an
optional task command whose exit code is the base protocol — exit 0 means
``passed``, non-zero ``failed``, timeout ``timeout``, and no configured
command ``unavailable``. A JSON status line on stdout is an optional detail
enhancement, never a requirement.

This module must stay free of adapter, prompt, reviewer, and LLM imports
(AGENTS.md invariant 2); an architecture test locks that boundary.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import signal
import subprocess
import time
from pathlib import Path

from pact_core.schemas import (
    FinalValidationResult,
    VerificationCheck,
    VerificationResult,
    VerificationStatus,
)

_TAIL_CHARS = 4000


def _git(workspace: Path, *args: str) -> subprocess.CompletedProcess[str]:
    git = shutil.which("git")
    if git is None:
        raise RuntimeError("verification requires git on PATH")
    env = os.environ.copy()
    env["GIT_OPTIONAL_LOCKS"] = "0"
    return subprocess.run(
        [git, *args],
        cwd=workspace,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )


def run_builtin_checks(
    *,
    workspace: Path,
    checkpoint_commit: str,
    baseline_commit: str,
    namespace_violations: list[str],
    required_artifacts: list[Path],
) -> list[VerificationCheck]:
    """Run the five always-on structural checks against one checkpoint."""
    checks: list[VerificationCheck] = []

    readable = _git(workspace, "cat-file", "-e", f"{checkpoint_commit}^{{commit}}")
    checks.append(
        VerificationCheck(
            name="checkpoint_readable",
            passed=readable.returncode == 0,
            detail="" if readable.returncode == 0 else readable.stderr.strip(),
        )
    )

    patch = _git(
        workspace,
        "diff",
        "--binary",
        "--full-index",
        "--no-ext-diff",
        baseline_commit,
        checkpoint_commit,
    )
    checks.append(
        VerificationCheck(
            name="patch_generatable",
            passed=patch.returncode == 0,
            detail="" if patch.returncode == 0 else patch.stderr.strip(),
        )
    )

    whitespace = _git(workspace, "diff", "--check", baseline_commit, checkpoint_commit)
    checks.append(
        VerificationCheck(
            name="diff_check_clean",
            passed=whitespace.returncode == 0,
            detail=whitespace.stdout.strip()[:_TAIL_CHARS] if whitespace.returncode != 0 else "",
        )
    )

    checks.append(
        VerificationCheck(
            name="namespace_clean",
            passed=not namespace_violations,
            detail=", ".join(namespace_violations),
        )
    )

    missing = [str(path) for path in required_artifacts if not path.is_file()]
    checks.append(
        VerificationCheck(
            name="required_artifacts_present",
            passed=not missing,
            detail=", ".join(missing),
        )
    )
    return checks


def _optional_status_line_check(stdout: str, exit_code: int) -> VerificationCheck | None:
    for line in reversed(stdout.splitlines()):
        stripped = line.strip()
        if not (stripped.startswith("{") and stripped.endswith("}")):
            continue
        try:
            parsed = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            return VerificationCheck(
                name="command_status_line",
                passed=exit_code == 0,
                detail=stripped[:_TAIL_CHARS],
            )
    return None


def _run_task_command(
    command: str,
    *,
    workdir: Path,
    timeout_seconds: float,
    env_extra: dict[str, str],
) -> tuple[VerificationStatus, int | None, str, str, float]:
    env = os.environ.copy()
    env.update(env_extra)
    started = time.monotonic()
    process = subprocess.Popen(
        command,
        shell=True,
        cwd=workdir,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )
    try:
        stdout, stderr = process.communicate(timeout=timeout_seconds)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        stdout, stderr = process.communicate()
        duration = time.monotonic() - started
        return "timeout", None, stdout or "", stderr or "", duration
    duration = time.monotonic() - started
    status: VerificationStatus = "passed" if process.returncode == 0 else "failed"
    return status, process.returncode, stdout, stderr, duration


def run_verification(
    *,
    workspace: Path,
    workdir: Path,
    checkpoint_commit: str,
    baseline_commit: str,
    namespace_violations: list[str],
    required_artifacts: list[Path],
    command: str | None,
    timeout_seconds: float,
    loop_dir: Path,
    round_number: int,
    patch_path: Path,
) -> VerificationResult:
    """Verify one checkpoint: built-in checks first, then the task command.

    ``workdir`` must be a disposable checkout that exactly matches
    ``checkpoint_commit``; the caller owns its creation and destruction.
    """
    checks = run_builtin_checks(
        workspace=workspace,
        checkpoint_commit=checkpoint_commit,
        baseline_commit=baseline_commit,
        namespace_violations=namespace_violations,
        required_artifacts=required_artifacts,
    )
    if not all(check.passed for check in checks):
        return VerificationResult(status="failed", checks=checks, command=command or "")

    if command is None:
        return VerificationResult(status="unavailable", checks=checks)

    status, exit_code, stdout, stderr, duration = _run_task_command(
        command,
        workdir=workdir,
        timeout_seconds=timeout_seconds,
        env_extra={
            "PACT_LOOP_DIR": str(loop_dir),
            "PACT_ROUND": str(round_number),
            "PACT_PATCH_PATH": str(patch_path),
        },
    )
    if exit_code is not None:
        status_line = _optional_status_line_check(stdout, exit_code)
        if status_line is not None:
            checks = [*checks, status_line]
    return VerificationResult(
        status=status,
        checks=checks,
        command=command,
        exit_code=exit_code,
        duration_seconds=duration,
        stdout_tail=stdout[-_TAIL_CHARS:],
        stderr_tail=stderr[-_TAIL_CHARS:],
    )


def run_final_validation(
    *,
    command: str | None,
    workdir: Path,
    timeout_seconds: float,
    loop_dir: Path,
    baseline_commit: str,
    candidate_commit: str,
    patch_path: Path,
) -> FinalValidationResult:
    """Run one opaque terminal validator after agent convergence.

    The command runs at the candidate checkout for convenience, but any
    validator that compares revisions must use the explicit baseline and
    candidate environment variables rather than inferring meaning from HEAD.
    This result is controller-only evidence and must never enter a role prompt.
    """
    if command is None:
        return FinalValidationResult(status="not_configured")

    command_sha256 = hashlib.sha256(command.encode("utf-8")).hexdigest()
    try:
        status, exit_code, stdout, stderr, duration = _run_task_command(
            command,
            workdir=workdir,
            timeout_seconds=timeout_seconds,
            env_extra={
                "PACT_LOOP_DIR": str(loop_dir),
                "PACT_BASELINE_COMMIT": baseline_commit,
                "PACT_CANDIDATE_COMMIT": candidate_commit,
                "PACT_FINAL_PATCH_PATH": str(patch_path),
            },
        )
    except OSError as exc:
        return FinalValidationResult(
            status="unavailable",
            command_sha256=command_sha256,
            stderr_tail=str(exc)[-_TAIL_CHARS:],
        )
    return FinalValidationResult(
        status=status,
        command_sha256=command_sha256,
        exit_code=exit_code,
        duration_seconds=duration,
        stdout_tail=stdout[-_TAIL_CHARS:],
        stderr_tail=stderr[-_TAIL_CHARS:],
    )
