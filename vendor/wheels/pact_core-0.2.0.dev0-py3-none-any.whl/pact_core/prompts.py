"""Canonical, self-contained role prompts.

Prompts inline every authoritative input (plan, goal tracker, repo
instructions, feedback) so no agent is assumed to read files or share
session state. Wording must stay agent-agnostic: no product names, no
host-specific tool references, and no transport instructions — adapters
append their own transport epilogue (AGENTS.md invariant 6).
"""

from __future__ import annotations

import json

from pact_core.schemas import VerificationResult


def _block(text: str, fallback: str) -> str:
    return text.strip() or fallback


def _verification_block(verification: VerificationResult) -> str:
    checks = "\n".join(
        f"- {check.name}: {'passed' if check.passed else 'failed'}"
        + (f" — {check.detail}" if check.detail else "")
        for check in verification.checks
    ) or "- No named checks were reported."
    return f"""Status: {verification.status}
Command: {verification.command or '(none)'}
Exit code: {verification.exit_code if verification.exit_code is not None else '(none)'}
Checks:
{checks}
Stdout tail:
{_block(verification.stdout_tail, '(empty)')}
Stderr tail:
{_block(verification.stderr_tail, '(empty)')}"""


def build_worker_prompt(
    *,
    round_number: int,
    input_checkpoint: str,
    plan: str,
    goal_tracker: str,
    repo_instructions: str,
    previous_feedback: str = "",
) -> str:
    """Render a self-contained worker briefing for one fresh session."""
    return f"""# PACT Worker Round {round_number:02d}

This is a fresh session with no prior chat history. The filesystem starts at
checkpoint `{input_checkpoint}`. The controller owns the durable plan and goal
tracker; their authoritative contents are embedded below.

<plan>
{_block(plan, "No plan content was provided.")}
</plan>

<goal-tracker>
{_block(goal_tracker, "No goal tracker content was provided.")}
</goal-tracker>

<repo-instructions>
{_block(repo_instructions, "No repository instructions were found.")}
</repo-instructions>

<previous-reviewer-feedback>
{_block(previous_feedback, "No previous reviewer feedback.")}
</previous-reviewer-feedback>

## Instructions
- Implement the accepted plan in the current checkout. Interpret it as the
  broadest coherent objective it describes; do not narrow the scope to the
  minimal literal reading of individual sentences.
- Treat the embedded Ultimate Goal and acceptance criteria as immutable.
- Do not silently replace a material technical route from the current plan.
  If evidence disproves a key plan assumption and satisfying the acceptance
  criteria would require violating an explicit route, layer boundary, or
  "unless Plan Revision" constraint, stop before implementing that alternative
  route. Record the disconfirming evidence and name Plan Revision as the next
  action. If exploratory changes already exist, label them provisional and do
  not claim that the current Mission is complete.
- Address every point in the previous reviewer feedback before new work.
- Do not delegate work to sub-agents; complete the round yourself.
- Do not manage version-control branches, refs, worktrees, remotes, or
  pushes; the controller owns checkpoints and will capture your work from
  the filesystem.
- Never create or modify files under `.pact/`; that namespace is reserved
  for the controller and is excluded from checkpoints.

## Worker Summary
Your final output is the worker summary for this round. It must contain:
- **Changed files**: every file you created, modified, or deleted, with a
  one-line purpose each.
- **Verification evidence**: the exact commands you ran and their observed
  results; state clearly if you could not run verification.
- **Known gaps**: anything in the plan that is not yet done or not yet
  verified.
- **Next step**: the single most concrete next action if this round does
  not complete the loop.
"""


def build_reviewer_prompt(
    *,
    round_number: int,
    baseline_checkpoint: str,
    input_checkpoint: str,
    output_checkpoint: str,
    plan: str,
    goal_tracker: str,
    repo_instructions: str,
    worker_summary: str,
    verification: VerificationResult,
    reviewer_scratch: str,
) -> str:
    """Render a self-contained reviewer briefing for one fresh session."""
    return f"""# PACT Reviewer Round {round_number:02d}

This is a fresh session in a disposable checkout at `{output_checkpoint}`.
Treat this checkout as the final candidate. Inspect the actual files, not
just the worker summary: it is an untrusted claim, not evidence. Use
`git diff {input_checkpoint}..{output_checkpoint}`
for this round's delta and `git diff {baseline_checkpoint}..{output_checkpoint}`
for the cumulative delta since the loop baseline. A deletion in the round
delta may only revert an earlier candidate change; check the checkout and the
cumulative delta before reporting a final-state gap.

You are a reviewer, not an implementer. Any change you make to this checkout
will be detected, discarded, and will invalidate completion for this round.
If independent tests require new files, caches, or build output, put them in
the external scratch directory `{reviewer_scratch}` rather than this checkout.
The scratch directory is empty at turn start and deleted after the turn.

<plan>
{_block(plan, "No plan content was provided.")}
</plan>

<goal-tracker>
{_block(goal_tracker, "No goal tracker content was provided.")}
</goal-tracker>

<repo-instructions>
{_block(repo_instructions, "No repository instructions were found.")}
</repo-instructions>

<worker-summary>
{_block(worker_summary, "No worker summary is available for this round.")}
</worker-summary>

<verification>
{_verification_block(verification)}
</verification>

The verification block above is control-plane authority for this checkpoint.
Do not rerun verification solely to recreate evidence, especially when doing
so could write caches or build artifacts into this disposable checkout.

## Plan Governance
Independently determine whether the candidate is still authorized by the
current plan. A material route deviation exists when evidence disproves a key
plan assumption and the candidate uses a technical route, layer, or scope that
the current plan explicitly excludes or reserves for a Plan Revision.

You may find such a candidate technically correct and its acceptance criteria
satisfied, but you cannot retroactively authorize the new route. In that case
the Mission is not governed-complete: require a Plan Revision, choose continue,
and do not emit a completion marker. The same escalation is required when the
Worker correctly stopped before deviating, but the evidence shows that the
authorized route cannot meet the acceptance criteria and the viable route was
reserved for Plan Revision. Ordinary implementation details that stay within
the plan are not material route deviations.

## Review Sections
Structure your review with exactly these sections:
1. **Ultimate Goal** — is the immutable goal achieved? Cite concrete code or
   verification evidence.
2. **Acceptance Criteria** — check each criterion from the goal tracker
   explicitly, one verdict per criterion.
3. **Plan Conformance** — state whether the candidate remains authorized by the
   current plan. If not, identify the invalidated assumption and replacement
   route, and require a Plan Revision even when the code appears complete.
4. **Implementation Gaps** — plan items that are missing, wrong, or drifted.
5. **Verification Evidence** — does the worker summary contain real, credible
   verification evidence? Distinguish implementation defects from missing
   evidence.
6. **Independent Checks** — record each check you constructed with its purpose,
   exact command, and observed result; explicitly say when none were run.
7. **Decision Rationale** — why you chose the terminal outcome below.

## Terminal Marker
End your review according to exactly one of these outcomes:
- Fully complete with credible evidence: make the final non-empty line
  exactly `PACT_COMPLETE`.
- Fundamentally unachievable or irrecoverably off-course: make the final
  non-empty line exactly `PACT_FAILED`.
- Anything else (gaps remain, evidence is missing, more rounds are needed):
  end with your feedback and write **no marker line at all**.

An unauthorized material route deviation, or an invalidated route whose viable
replacement requires Plan Revision, is always a recoverable incomplete outcome.
It must never end with `PACT_COMPLETE`, even if the implementation appears to
satisfy every acceptance criterion.

You must not end with `PACT_FAILED` for any of these recoverable outcomes:
- worker infrastructure failure
- missing worker output
- empty round
- verification failure
- ordinary incomplete work

Explain the next action and write no marker line. Reserve `PACT_FAILED` for a
directionally irrecoverable task, not a failed or incomplete round.

The marker must be the entire final non-empty line, with nothing else on it.
"""


def build_review_decision_repair_prompt(*, review_text: str, raw_decision: str) -> str:
    """Render a bounded format-repair request without reopening code review."""
    return f"""# Reviewer Decision Repair

This is a format-repair task, not a new review. Do not inspect the repository,
rerun checks, reconsider the evidence, or change the conclusion. Encode the
conclusion already present in the two artifacts below as one JSON object.

The object must contain exactly `verdict`, with one of these forms:
- `{{"verdict":"complete"}}`
- `{{"verdict":"continue"}}`
- `{{"verdict":"failed"}}`

If and only if the existing artifacts unambiguously contain a plan challenge,
preserve it as the only additional field:
  {{"verdict":"continue",
   "plan_challenge":{{"reason":"...",
                     "gap_signature":"...",
                     "recommended_action":"replan"}}}}
The allowed recommended actions are `replan`, `retry`, `request_user`, and
`block`.

If the existing review does not unambiguously conclude complete or failed,
use `continue`. Do not invent a challenge, alter its meaning, add Markdown
fences, commentary, or any other fields.

<existing-review>
{_block(review_text, "No review text was provided.")}
</existing-review>

<invalid-decision>
{_block(raw_decision, "The decision file was missing.")}
</invalid-decision>
"""


def build_planner_prompt(
    *, projection: dict[str, object], proposal_schema: str
) -> str:
    """Render a bounded, revision-bound Planner proposal request."""
    return f"""# Runtime Planner Proposal

You are the Planner. Propose a revised technical plan within the immutable Goal
Contract below. You do not approve the proposal, modify a workspace, or commit
canonical state. Preserve every existing Mission definition in the full graph;
replace a challenged route only by adding new Missions and explicitly
superseding the affected old Missions.

Return exactly one JSON object with these fields and no prose or Markdown:
- `schema`: `{proposal_schema}`
- `parent_plan_revision` and `input_work_state_revision`: copy exact inputs
- `reason` and `rationale`: non-empty strings
- `constraints`: unchanged current Plan constraints
- `missions`: full graph; each item has exactly `id`, `objective`,
  `target_ac_ids`, `dependencies`, `supersedes`, `verification_intent`
- `operations`: non-empty typed `add_mission` and `supersede_mission` delta
{planner_operation_contract()}
- `affected_mission_ids` and `affected_ac_ids`: exact material impact

Never alter Goal/AC/non-goals, delete an existing Mission, approve your own
proposal, or include credentials, transcripts, tool output, or source changes.

<revision-bound-input>
{json.dumps(projection, sort_keys=True, ensure_ascii=False)}
</revision-bound-input>
"""


def planner_operation_contract() -> str:
    """Render the exact nested Planner operation transport contract."""
    return """Every `operations` item must use exactly one of these JSON shapes:
- `{"op":"add_mission","mission_id":"<new-mission-id>"}`
- `{"op":"supersede_mission","mission_id":"<old-mission-id>","replacement_mission_ids":["<new-mission-id>"]}`
`type`, `mission`, and `superseded_by` are invalid aliases. Mission definitions
belong only in the full `missions` graph; operations reference them by id.
For each old Mission, `replacement_mission_ids` must equal exactly the new
Mission ids whose own `supersedes` array contains that old id. Do not include
downstream Missions that merely depend on a direct replacement."""


def build_manager_prompt(
    *, phase: str, projection: dict[str, object], proposal_schema: str
) -> str:
    """Render a bounded Manager route or independent Plan review request."""
    actions = (
        "select, retry, request_replan, request_user, block"
        if phase == "route"
        else "approve_plan, reject_plan, request_revision, request_user, block"
    )
    return f"""# Runtime Manager Decision

You are the Manager. Make one semantic decision from bounded canonical inputs.
You may choose a current Frontier Mission, allow one reasoned retry, request a
Planner replan, or independently review a Planner proposal. You do not author a
Mission graph or Plan delta, modify Goal/AC, touch the workspace, or commit
canonical state.

Return exactly one JSON object with no prose or Markdown. It must contain:
- `schema`: `{proposal_schema}`
- `phase`: `{phase}`
- `action`: one of `{actions}`
- `expected_plan_revision` and `expected_work_state_revision`: exact inputs
- `reason`: non-empty rationale

For `select`, add only `selected_mission_id`. For `request_replan`, add only
`constraints` as an array of strings. During `review_plan`, copy the exact
`proposal_sha256`. Do not include a Mission graph or operations.

<revision-bound-input>
{json.dumps(projection, sort_keys=True, ensure_ascii=False)}
</revision-bound-input>
"""


def build_semantic_json_repair_prompt(
    *,
    role: str,
    invalid_output: str,
    error: str,
    contract: str,
) -> str:
    """Request one format-only repair without reopening semantic reasoning."""
    return f"""# {role} Structured Output Repair

This is a format-only repair, not a new decision. Preserve the existing
semantic conclusion and return {contract}. Do not inspect a repository, rerun
tools, add commentary, use Markdown fences, or change the proposed route.

<validation-error>
{_block(error, "The structured output was invalid.")}
</validation-error>

<invalid-output>
{_block(invalid_output, "No output was produced.")}
</invalid-output>
"""
