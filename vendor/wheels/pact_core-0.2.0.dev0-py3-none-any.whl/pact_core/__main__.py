import sys

from pact_core.cli import main

sys.exit(main())
