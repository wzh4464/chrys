"""pact-core: agent-agnostic PACT protocol runner."""

__version__ = "0.2.0.dev0"
